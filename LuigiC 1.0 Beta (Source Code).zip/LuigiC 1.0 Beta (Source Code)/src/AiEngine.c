#include "AiEngine.h"
#include "snes/snes.h"
#include "smw_rtl.h"
#include "variables.h"
#include "common_cpu_infra.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#ifdef _WIN32
#include <direct.h>
#define MKDIR(s) _mkdir(s)
#else
#include <sys/stat.h>
#define MKDIR(s) mkdir(s, 0755)
#endif


#define SEARCH_LOOKAHEAD 3000
#define MAX_EXPANSIONS 5000
#define SNAPSHOT_SIZE 0xC000  

static AiNode node_pool[AI_MAX_NODES];
static int nodes_count = 0;
AiPath g_ai_best_path;
static uint8_t *state_memory = NULL;
static Snapshot before_ai_snapshot;
extern Snes *g_snes;

bool g_ai_capture_inputs = true;
static uint16 recorded_inputs[10000];
static uint16 recorded_x[10000];
static int recorded_length = 0;

static AiStrategy current_strat;
static bool strat_loaded = false;
static int strat_index = 0;

static uint16_t plan_inputs[2000];
static int plan_length = 0;
static int plan_ptr = 0;

static inline uint16_t GetX() { return g_ram[0x94] | (g_ram[0x95] << 8); }
static inline uint16_t GetY() { return g_ram[0x96] | (g_ram[0x97] << 8); }

static bool IsTileSolid(uint16_t x, uint16_t y) {
    uint16_t tx = x;
    uint16_t ty = y;
    uint16_t tile_idx = ((tx >> 4) & 0xF) | (((ty >> 4) & 0xF) << 4) | ((tx >> 8) << 8);
    uint8_t lo = g_ram[0xC800 + (tile_idx % 0x8000)];
    return (lo >= 0x11 && lo <= 0x6D) || (lo >= 0x01 && lo <= 0x05);
}

void AiEngine_Init(void) {
    if (!state_memory) {
        state_memory = (uint8_t*)malloc(AI_MAX_NODES * SNAPSHOT_SIZE);
        if (!state_memory) exit(1); 
        for(int i=0; i<AI_MAX_NODES; i++) node_pool[i].ram_state = &state_memory[i * SNAPSHOT_SIZE];
    }
    MKDIR("strategies");
    printf("SMW AI v30.9 (Hazard Aware) Initialized.\n");
}

void AiEngine_RecordFrame(uint16_t input, uint16_t x) {
    if (recorded_length < 10000) {
        recorded_inputs[recorded_length] = input;
        recorded_x[recorded_length] = x;
        recorded_length++;
    }
}

void AiEngine_SaveStrategy(void) {
    if (recorded_length == 0) return;
    uint16 current_level = g_ram[0x13BF];
    char folder[64], path[128];
    sprintf(folder, "strategies/%d", current_level);
    MKDIR(folder);
    sprintf(path, "%s/best.dat", folder);
    AiStrategy strat = {current_level, {0}, {0}, recorded_length};
    memcpy(strat.inputs, recorded_inputs, recorded_length * 2);
    memcpy(strat.x_pos, recorded_x, recorded_length * 2);
    FILE* f = fopen(path, "wb");
    if (f) { fwrite(&strat, sizeof(AiStrategy), 1, f); fclose(f); }
    recorded_length = 0;
}

void AiEngine_LoadStrategy(void) {
    strat_loaded = false;
    strat_index = 0;
    uint16 current_level = g_ram[0x13BF];
    char path[128];
    sprintf(path, "strategies/%d/best.dat", current_level);
    FILE* f = fopen(path, "rb");
    if (f) { 
        fread(&current_strat, sizeof(AiStrategy), 1, f); 
        fclose(f); 
        strat_loaded = true; 
    }
}

static int open_set[AI_MAX_NODES];
static int open_set_count = 0;
static uint16_t visited_map[1024][128];

static void HeapPush(int node_idx) {
    int i = open_set_count++;
    while (i > 0) {
        int p = (i - 1) / 2;
        if (node_pool[open_set[p]].cost_f <= node_pool[node_idx].cost_f) break;
        open_set[i] = open_set[p];
        i = p;
    }
    open_set[i] = node_idx;
}

static int HeapPop() {
    if (open_set_count == 0) return -1;
    int res = open_set[0];
    int node_idx = open_set[--open_set_count];
    int i = 0;
    while (i * 2 + 1 < open_set_count) {
        int child = i * 2 + 1;
        if (child + 1 < open_set_count && node_pool[open_set[child+1]].cost_f < node_pool[open_set[child]].cost_f) child++;
        if (node_pool[node_idx].cost_f <= node_pool[open_set[child]].cost_f) break;
        open_set[i] = open_set[child];
        i = child;
    }
    open_set[i] = node_idx;
    return res;
}

uint16_t AiEngine_GetBestAction(void) {
    if (g_ai_capture_inputs) return g_snes->input1_currentState;

    uint16_t cx = GetX(), cy = GetY();
    uint8_t player_state = g_ram[0x71];

    if (plan_ptr < plan_length && plan_ptr < 45 && player_state < 9) {
        uint16_t input = plan_inputs[plan_ptr++];
        // REAL-TIME: If in water and jumping, MUST hold UP to get out
        if (g_ram[0x75] > 0 && (input & (AI_KEY_A | AI_KEY_B))) {
            input |= AI_KEY_UP; 
            if (plan_ptr % 2 == 0) input &= ~(AI_KEY_A | AI_KEY_B);
        }
        return input;
    }

    MakeSnapshot(&before_ai_snapshot);

    nodes_count = 0;
    open_set_count = 0;
    memset(visited_map, 0xFF, sizeof(visited_map));

    AiNode* root = &node_pool[nodes_count++];
    memcpy(root->ram_state, g_ram, SNAPSHOT_SIZE);
    root->parent_index = -1;
    root->depth = 0;
    root->pos.x = cx;
    root->pos.y = cy;
    root->cost_f = (float)SEARCH_LOOKAHEAD;
    HeapPush(0);

    typedef struct { uint16_t buttons; int frames; } Macro;
    Macro macros[] = {
        {AI_KEY_RIGHT | AI_KEY_Y,            15}, // Sprint (Shortened for faster reaction)
        {AI_KEY_RIGHT | AI_KEY_Y,            5},  // Micro-step
        {AI_KEY_RIGHT | AI_KEY_Y | AI_KEY_B, 42}, // Full Jump
        {AI_KEY_RIGHT | AI_KEY_Y | AI_KEY_B, 20}, // Short Hop
        {AI_KEY_RIGHT | AI_KEY_Y | AI_KEY_A, 30}, // Spin Jump
        {AI_KEY_B,                           35}, // Vertical Climb
        {AI_KEY_DOWN,                        15}, // Down Pipe
        {AI_KEY_LEFT | AI_KEY_Y,             10}, 
    };
    int num_macros = 8;

    int best_leaf = 0;
    float min_h = 1e9f;
    int expansions = 0;

    while (open_set_count > 0 && expansions < MAX_EXPANSIONS) {
        int curr = HeapPop();
        AiNode* parent = &node_pool[curr];

        uint16_t vx = parent->pos.x >> 4;
        uint16_t vy = (parent->pos.y >> 4) & 0x7F;
        if (vx < 1024 && visited_map[vx][vy] <= parent->depth) continue;
        visited_map[vx][vy] = parent->depth;

        expansions++;

        for (int i=0; i<num_macros; i++) {
            memcpy(g_ram, parent->ram_state, SNAPSHOT_SIZE);
            
            bool hit = false;
            bool success = false;
            bool on_land_sprite = false;
            bool touched_deadly = false;
            uint8_t start_powerup = g_ram[0x19];
            
            bool potential_item_visible = false;
            bool goal_visible = false;
            int goal_dist_sq = 1000000;
            int item_dist_sq = 1000000;
            float fear_penalty = 0.0f;
            float pit_penalty = 0.0f;

            for (int f=0; f<macros[i].frames; f++) {
                uint16_t input = macros[i].buttons;
                
                // SIMULATION: Water Exit Logic
                if (g_ram[0x75] > 0 && (input & (AI_KEY_A | AI_KEY_B))) {
                    input |= AI_KEY_UP; // Required to jump out of water
                    if (f % 2 == 0) input &= ~(AI_KEY_A | AI_KEY_B);
                }

                g_snes->input1_currentState = input;
                SmwRunOneFrameOfGame();

                // PROACTIVE PIT DETECTION: Check ahead of Mario
                uint16_t px = GetX(), py = GetY();
                bool found_floor = false;
                // Look directly below and slightly ahead
                int scan_x = (g_ram[0x7B] < 0x80) ? 32 : -32; 
                for (int dy = 0; dy <= 128; dy += 16) {
                    if (IsTileSolid(px, py + dy) || IsTileSolid(px + scan_x, py + dy)) { 
                        found_floor = true; 
                        break; 
                    }
                }
                if (!found_floor) pit_penalty += 300.0f; 

                // Sprite Detection
                for (int s=0; s<12; s++) {
                    if (g_ram[0x14C8 + s] < 8) continue;
                    uint8_t id = g_ram[0x9E + s];
                    uint16_t sx = g_ram[0x00E4 + s] | (g_ram[0x14E0 + s] << 8);
                    uint16_t sy = g_ram[0x00D8 + s] | (g_ram[0x14D4 + s] << 8);
                    int dx = (int)GetX() - (int)sx;
                    int dy = (int)GetY() - (int)sy;
                    int dist_sq = dx*dx + dy*dy;

                    if (id == 0x5D && dx < 24 && dy < 32) on_land_sprite = true; // "Land" platform
                    if (id == 0xA4 && dx < 40 && dy < 40) touched_deadly = true; // Deadly Spike Ball (A4)

                    // Goal Tape (7B), Orb (4A)
                    if (id == 0x7B || id == 0x4A) {
                        goal_visible = true;
                        if (dist_sq < goal_dist_sq) goal_dist_sq = dist_sq;
                    }
                    
                    // Items: Mushroom (74, 41), Flower (75, 42), Feather (77, 44), Star (43), 1Up (78)
                    bool is_item = (id == 0x74 || id == 0x75 || id == 0x77 || id == 0x78 || id == 0x41 || id == 0x42 || id == 0x43 || id == 0x44 || id == 0x3E || id == 0x80 || id == 0x35 || id == 0x21);
                    if (is_item) {
                        potential_item_visible = true;
                        if (dist_sq < item_dist_sq) item_dist_sq = dist_sq;
                    }

                    // Enemy Avoidance (Fear Factor)
                    if (!is_item && !goal_visible && !on_land_sprite && id != 0x5D && id != 0x62 && id != 0x63) {
                        float dist = sqrtf((float)dist_sq);
                        if (dist < 48.0f) {
                            success = false;
                            float penalty_val = (48.0f - dist);
                            fear_penalty += penalty_val * penalty_val * 20.0f;
                        }
                    }
                }

                if (g_ram[0x88] > 0 || g_ram[0x89] > 0 || g_ram[0x71] == 5) success = true; 
                if (g_ram[0x71] >= 9 || GetY() > 0x1B0 || g_ram[0x1497] > 0 || g_ram[0x19] < start_powerup) { 
                    hit = true; 
                    break; 
                }
            }

            if (nodes_count >= AI_MAX_NODES) break;

            AiNode* child = &node_pool[nodes_count];
            memcpy(child->ram_state, g_ram, SNAPSHOT_SIZE);
            child->parent_index = curr;
            child->depth = parent->depth + 1;
            child->pos.x = GetX();
            child->pos.y = GetY();
            child->input_used = macros[i].buttons;
            child->macro_frames = macros[i].frames;

            float progress_dx = (float)(child->pos.x - cx);
            float progress_dy = (float)(cy - child->pos.y); 
            
            // Doubled jump reward (Upward progress)
            float progress = (progress_dx * 1.0f) + (progress_dy > 0 ? progress_dy * 8.0f : progress_dy * 0.1f);
            
            // Extra bonus for being airborne if we are moving forward over a pit area
            if (g_ram[0x13EF] == 0 && progress_dx > 5.0f) progress += 500.0f; 

            // GOAL ORIENTED HEURISTIC
            if (goal_visible) {
                float dist = sqrtf((float)goal_dist_sq);
                progress += (10000.0f - dist) * 2.0f;
            } else if (progress_dx < 0 && !potential_item_visible) {
                progress -= 50.0f;
            }

            // ITEM COLLECTION HEURISTIC
            if (potential_item_visible) {
                float dist = sqrtf((float)item_dist_sq);
                progress += (5000.0f - dist) * 1.5f; 
            }
            
            if (g_ram[0x19] > start_powerup) progress += 15000.0f; // HUGE priority for items

            // Bonus for jumping against blocks (hitting ceiling) if it might reveal an item
            if ((g_ram[0x77] & 8) && (macros[i].buttons & AI_KEY_B)) {
                 progress += 1000.0f; // Encourage hitting blocks
            }

            if (success) progress += 800.0f;
            if (on_land_sprite) progress += 1000.0f; 

            // HEIGHT SAFETY: Penalize being too low
            if (child->pos.y > 0x180) progress -= (float)(child->pos.y - 0x180) * 10.0f;

            if ((macros[i].buttons & AI_KEY_RIGHT) && g_ram[0x7B] == 0 && !hit && !success && !potential_item_visible && !goal_visible) progress -= 50.0f; 

            float h = (float)SEARCH_LOOKAHEAD - progress;
            if (h < 0) h = 0;

            // ABSOLUTE PENALTY FOR DEADLY SPRITE 4A
            float penalty = hit ? 10000000.0f : 0;
            if (touched_deadly) penalty = 50000000.0f; // 5x more dangerous than death itself

            child->cost_f = h + (float)child->depth * 15.0f + penalty + fear_penalty + pit_penalty;

            if (child->cost_f < min_h) {
                min_h = child->cost_f;
                best_leaf = nodes_count;
            }
            HeapPush(nodes_count++);
        }
    }

    int p = best_leaf;
    static uint16_t temp_inputs[4000];
    int temp_ptr = 0;
    g_ai_best_path.length = 0;

    while (p != -1 && node_pool[p].parent_index != -1) {
        AiNode* n = &node_pool[p];
        if (g_ai_best_path.length < AI_MAX_DEPTH) g_ai_best_path.points[g_ai_best_path.length++] = n->pos;
        for (int f=0; f<n->macro_frames; f++) {
            if (temp_ptr < 4000) temp_inputs[temp_ptr++] = n->input_used;
        }
        p = n->parent_index;
    }

    plan_length = temp_ptr;
    for (int i=0; i<plan_length && i < 2000; i++) plan_inputs[i] = temp_inputs[plan_length - 1 - i];
    if (plan_length > 2000) plan_length = 2000;
    plan_ptr = 0;

    RestoreSnapshot(&before_ai_snapshot);
    if (plan_length > 0) return plan_inputs[plan_ptr++];
    return 0;
}
