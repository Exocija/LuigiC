#pragma once

void SwitchImpl_Init();
void SwitchImpl_Exit();

// Error messages

void ThrowMissingROM();