#include "consts.h"
#include "funcs.h"
#include "smw_rtl.h"
#include "variables.h"
#include "assets/smw_assets.h"
#include "snes/snes.h"
void (*kBufferScrollingTiles_Layer1_Main_PtrsLong058823[32])(void) = {
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
};
void (*kBufferScrollingTiles_Layer2_Main_PtrsLong05888C[32])(void) = {
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2_VerticalLevel,
    &BufferScrollingTiles_Layer2_VerticalLevel,
    &BufferScrollingTiles_Layer2_VerticalLevel,
    &BufferScrollingTiles_Layer2_VerticalLevel,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2,
};
void (*kBufferScrollingTiles_Layer1_Init_PtrsLong0588F5[32])(void) = {
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_VerticalLevel,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1_NoScroll,
    &BufferScrollingTiles_Layer1,
    &BufferScrollingTiles_Layer1,
};
void (*kBufferScrollingTiles_Layer2_Init_PtrsLong05895E[32])(void) = {
    &BufferScrollingTiles_Layer2_Background,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2_VerticalLevel,
    &BufferScrollingTiles_Layer2_VerticalLevel,
    &BufferScrollingTiles_Layer2_VerticalLevel,
    &BufferScrollingTiles_Layer2_VerticalLevel,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_Background,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_Background,
    &BufferScrollingTiles_Layer2_Background,
    &BufferScrollingTiles_Layer2_Background,
    &BufferScrollingTiles_Layer2,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_Background,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_NoScroll,
    &BufferScrollingTiles_Layer2_Background,
    &BufferScrollingTiles_Layer2,
};
void (*kProcessScrollSprites_Ptrs05BC87[15])(void) = {
    &Layer1SpecialScrolling00_VariableScroll,
    &Layer1SpecialScrolling00_VariableScroll,
    &ProcessScrollSprites_Return,
    &ProcessScrollSprites_Return,
    &Layer1SpecialScrolling04_Unused,
    &Layer1SpecialScrolling05_Unused,
    &ProcessScrollSprites_Return,
    &Spr0EC_UnusedSprite_Return05BFF5,
    &Layer1SpecialScrolling08_Layer2ScrollSOrL,
    &ProcessScrollSprites_Return,
    &Layer1SpecialScrolling0A_Unused,
    &Layer1SpecialScrolling0B_Layer2OnOffControlled,
    &Layer1SpecialScrolling0C_RegularAutoScroll,
    &ProcessScrollSprites_Return,
    &ProcessScrollSprites_Return,
};
void (*kProcessScrollSprites_Ptrs05BCB8[15])(void) = {
    &Layer1SpecialScrolling00_VariableScroll,
    &Layer2SpecialScrolling01_VariableScroll,
    &Layer2SpecialScrolling02_Layer2Smash,
    &Layer2SpecialScrolling03_Layer2Scroll,
    &Layer1SpecialScrolling04_Unused,
    &ProcessScrollSprites_Return,
    &Layer2SpecialScrolling06_Unused,
    &Spr0EC_UnusedSprite_Return05BFF5,
    &Layer1SpecialScrolling08_Layer2ScrollSOrL,
    &Layer2SpecialScrolling0D_FastBGScroll_NonFlagged,
    &Layer1SpecialScrolling0A_Unused,
    &Layer1SpecialScrolling0B_Layer2OnOffControlled,
    &Layer1SpecialScrolling0C_RegularAutoScroll,
    &Layer2SpecialScrolling0D_FastBGScroll_Flagged,
    &Layer2SpecialScrolling0E_Layer2ScrollWhenTouched,
};
void (*kInitializeScrollSprites_Ptrs05BCF0[15])(void) = {
    &Spr0E7_SpecialAutoScroll,
    &Spr0E7_SpecialAutoScroll,
    &Spr0E9_Layer2Smash,
    &Spr0EA_Layer2Scroll,
    &Spr0EB_UnusedSprite,
    &Spr0EC_UnusedSprite,
    &Spr0ED_Layer2Falls,
    &InitializeScrollSprites_Return05BD35,
    &Spr0EF_Layer2ScrollSOrL,
    &ProcessScrollSprites_Return,
    &Spr0F1_UnusedSprite,
    &Spr0F2_Layer2OnOffControlled,
    &Spr0F3_RegularAutoScroll,
    &Spr0F4_FastBGScroll,
    &Spr0F5_Layer2ScrollWhenTouched,
};
void (*kUnk_5bd17[15])(void) = {
    &Spr0E7_SpecialAutoScroll_Layer2, &Spr0E7_SpecialAutoScroll_Layer2,      &ProcessScrollSprites_Return,
    &Spr0EA_Layer2Scroll_05BF20, &Spr0EB_UnusedSprite_05BDF0,      &ProcessScrollSprites_Return,
    &ProcessScrollSprites_Return,     &InitializeScrollSprites_Return05BD35, &Spr0EF_Layer2ScrollSOrL_05BEC6,
    &Spr0F4_FastBGScroll_05C022, &Spr0F1_UnusedSprite_05BE4D,      &ProcessScrollSprites_Return,
    &ProcessScrollSprites_Return,     &ProcessScrollSprites_Return,          &ProcessScrollSprites_Return,
};
void (*kProcessLevelEndRoutines_Ptrs05CC0E[4])(void) = {
    &ShowCourseClearText,
    &DisplayCourseClearTextBonusStars,
    &GiveTimeBonusAndBonusStars,
    &GiveTimeBonusAndBonusStars_Return,
};

static const uint8 kInitializeMap16Pointers_DATA_0581BB[64] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xe0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xfe, 0x0, 0x7f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xe0, 0x0, 0x0, 0x3, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,  };
static const uint16 kInitializeMap16Pointers_TilesetMap16Ptrs[15] = { 0x8b70, 0xbc00, 0xc800, 0xd400, 0xe300, 0xe300, 0xc800, 0x8b70, 0xc800, 0xd400, 0xd400, 0xd400, 0x8b70, 0xe300, 0xd400,  };
static const uint8 kLoadLevelHeader_VerticalTable[32] = { 0x0, 0x0, 0x80, 0x1, 0x81, 0x2, 0x82, 0x3, 0x83, 0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x80,  };
static const uint8 kLoadLevelHeader_LevMainScrnTbl[32] = { 0x15, 0x15, 0x17, 0x15, 0x15, 0x15, 0x17, 0x15, 0x17, 0x15, 0x15, 0x15, 0x15, 0x15, 0x4, 0x4, 0x15, 0x17, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x1, 0x2,  };
static const uint8 kLoadLevelHeader_LevSubScrnTbl[32] = { 0x2, 0x2, 0x0, 0x2, 0x2, 0x2, 0x0, 0x2, 0x0, 0x0, 0x2, 0x0, 0x2, 0x2, 0x13, 0x13, 0x0, 0x0, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x16, 0x15,  };
static const uint8 kLoadLevelHeader_LevCGADSUBtable[32] = { 0x24, 0x24, 0x24, 0x24, 0x24, 0x24, 0x20, 0x24, 0x24, 0x20, 0x24, 0x20, 0x70, 0x70, 0x24, 0x24, 0x20, 0xff, 0x24, 0x24, 0x24, 0x24, 0x24, 0x24, 0x24, 0x24, 0x24, 0x24, 0x24, 0x24, 0x21, 0x22,  };
static const uint8 kLoadLevelHeader_SpecialLevTable[32] = { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xc0, 0x0, 0x80, 0x0, 0x0, 0x0, 0x0, 0xc1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  };
static const uint8 kLoadLevelHeader_LevXYPPCCCTtbl[32] = { 0x20, 0x20, 0x20, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x20, 0x20, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,  };
static const uint8 kLoadLevelHeader_TimerTable[4] = { 0x0, 0x2, 0x3, 0x4,  };

const uint16 kCalculateRowOrColumnOfTilemapToUpdate_PipeMap16Ptrs[4] = { 0x8ab0, 0x84e0, 0x8af0, 0x8b30,  };

static const uint16 kDisplayMessage_DATA_05A580[8] = { 0xa751, 0x8751, 0x6751, 0x4751, 0x2751, 0x751, 0xe750, 0xc750,  };
static const uint8 kDisplayMessage_DATA_05A590[23] = { 0x14, 0x45, 0x3f, 0x8, 0x0, 0x29, 0xaa, 0x27, 0x26, 0x84, 0x95, 0xa9, 0x15, 0x13, 0xce, 0xa7, 0xa4, 0x25, 0xa5, 0x5, 0xa6, 0x2a, 0x28,  };
static const uint16 kDisplayMessage_DATA_05A5A7[25] = { 0x8d, 0x8d, 0x8d, 0x8d, 0x0, 0x291, 0x41d, 0x518, 0x61d, 0x8b7, 0x7b2, 0x30b, 0x83c, 0x99d, 0xa9e, 0x4a0, 0xa2c, 0x6a6, 0x730, 0x911, 0x5a4, 0x38f, 0x109, 0x20a, 0x191,  };
static const uint8 kDisplayMessage_DATA_05B106[2] = { 0x4c, 0x50,  };
static const uint8 kDisplayMessage_DATA_05B108[2] = { 0x50, 0x0,  };
static const uint8 kDisplayMessage_DATA_05B10A[2] = { 0x4, 0xfc,  };

const uint16 kDisplayMessage_SwitchBlockTileAndProperties[32] = { 0x35ad, 0x75ad, 0xb5ad, 0xf5ad, 0x35a7, 0x75a7, 0x35b7, 0x75b7, 0x37bd, 0x77bd, 0xb7bd, 0xf7bd, 0x37a7, 0x77a7, 0x37b7, 0x77b7, 0x39ad, 0x79ad, 0xb9ad, 0xf9ad, 0x39a7, 0x79a7, 0x39b7, 0x79b7, 0x3bbd, 0x7bbd, 0xbbbd, 0xfbbd, 0x3ba7, 0x7ba7, 0x3bb7, 0x7bb7,  };
const uint8 kDisplayMessage_SwitchBlockXAndYDisp[16] = { 0x50, 0x4f, 0x58, 0x4f, 0x50, 0x57, 0x58, 0x57, 0x92, 0x4f, 0x9a, 0x4f, 0x92, 0x57, 0x9a, 0x57,  };
const uint8 kBitTable_Bank05[8] = { 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1,  };
// todo: oob read
static const uint8 kLevelTileAnimations_DATA_05B96B[24] = { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x2, 0x2, 0x2, 0x2, 2,   0,   0,   0,   0,   0, };
static const uint8 kLevelTileAnimations_DATA_05B97D[14] = { 0x2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x0, 0x2, 0x2, 0x0,  };
static const uint8 kLevelTileAnimations_DATA_05B98B[14] = { 0x0, 0x5, 0xa, 0xf, 0x14, 0x14, 0x19, 0x14, 0xa, 0x14, 0x0, 0x5, 0x0, 0x14,  };
static const uint16 kSpr0F3_RegularAutoScroll_DATA_05BFFD[2] = { 0x0, 0x2,  };
static const uint16 kSpr0F3_RegularAutoScroll_MaxXSpeed[2] = { 0x80, 0x100,  };
static const uint8 kScrollLayer3_TideYAcceleration[2] = { 0xff, 0x1,  };
static const uint8 kScrollLayer3_TideMaxYSpeed[2] = { 0xfc, 0x4,  };
static const uint8 kScrollLayer3_TideMaxYPos[2] = { 0x30, 0xa0,  };
static const uint16 kLayer2SpecialScrolling0B_Layer2OnOffControlled_DATA_05C71B[2] = { 0x20, 0xc1,  };
static const uint16 kLayer2SpecialScrolling0B_Layer2OnOffControlled_DATA_05C71F[2] = { 0xffc0, 0x40,  };
static const uint16 kLayer2SpecialScrolling0B_Layer2OnOffControlled_DATA_05C723[2] = { 0xffff, 0x1,  };
static const uint16 kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C7F0[6] = { 0x0, 0x2f0, 0x8b0, 0x0, 0x0, 0x370,  };
static const uint16 kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C7FC[6] = { 0xd0, 0x350, 0xa30, 0x8, 0x40, 0x380,  };
static const uint8 kSpr0F5_Layer2ScrollWhenTouched_DATA_05C808[3] = { 0x0, 0x6, 0x8,  };
static const uint8 kSpr0F5_Layer2ScrollWhenTouched_DATA_05C80B[3] = { 0x3, 0x1, 0x2,  };
static const uint16 kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C80E[1] = { 0xc0,  };
static const uint16 kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C810[2] = { 0x0, 0xb0,  };
static const uint16 kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C814[2] = { 0xff80, 0xc0,  };
static const uint16 kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C818[2] = { 0xffff, 0x1,  };
static const uint16 kLayer2SpecialScrolling02_Layer2Smash_DATA_05C880[18] = { 0x0, 0x1c0, 0x300, 0x800, 0x838, 0xa00, 0x0, 0x380, 0x450, 0x890, 0x960, 0xe80, 0x4000, 0x4000, 0x4000, 0x4000, 0x4000, 0x0,  };
static const uint16 kLayer2SpecialScrolling02_Layer2Smash_DATA_05C8A4[18] = { 0x8, 0x300, 0x410, 0x838, 0x870, 0xb00, 0x8, 0x450, 0x4a0, 0x960, 0xa40, 0xfff, 0x5000, 0x5000, 0x5000, 0x5000, 0x5000, 0x80,  };
static const uint16 kLayer2SpecialScrolling02_Layer2Smash_DATA_05C8C8[27] = { 0xc0, 0xb0, 0x70, 0xc0, 0xc0, 0xc0, 0x0, 0x0, 0xc0, 0xb0, 0xa0, 0x70, 0xb0, 0xb0, 0xb0, 0x0, 0x0, 0xb0, 0x20, 0x20, 0x20, 0x10, 0x10, 0x10, 0x0, 0x0, 0x10,  };
static const uint16 kLayer2SpecialScrolling02_Layer2Smash_DATA_05C8FE[27] = { 0x100, 0x100, 0x800, 0x100, 0x100, 0x800, 0x0, 0x0, 0x180, 0xff00, 0xff00, 0x0, 0xff00, 0xff00, 0xff00, 0xff00, 0xff00, 0xff00, 0xf800, 0xf800, 0xf800, 0xf800, 0xf800, 0xf800, 0x0, 0x0, 0xfe40,  };
static const uint8 kLayer2SpecialScrolling02_Layer2Smash_DATA_05C934[27] = { 0x80, 0x40, 0x1, 0x80, 0x0, 0x0, 0x80, 0x0, 0x40, 0x0, 0x0, 0x20, 0x40, 0x0, 0x20, 0x0, 0x0, 0x20, 0x80, 0x80, 0x20, 0x80, 0x80, 0x20, 0x0, 0x0, 0xa0,  };
static const uint8 kSpr0E9_Layer2Smash_DATA_05C94F[3] = { 0x0, 0xc, 0x18,  };
static const uint8 kSpr0E9_Layer2Smash_DATA_05C952[3] = { 0x5, 0x5, 0x5,  };
static const uint8 kSpr0E7_SpecialAutoScroll_L1AndL2ScrollID[10] = { 0x1, 0x1, 0x1, 0x0, 0x1, 0x1, 0x1, 0x0, 0x1, 0x9,  };
static const uint8 kSpr0E7_SpecialAutoScroll_L1AndL2ScrollTypeIndex[10] = { 0x1, 0x0, 0x2, 0x0, 0x4, 0x3, 0x5, 0x0, 0x6, 0x0,  };
static const uint16 kMostlyUnusedScrollSpriteRoutine_UNK_05C9E5[17] = { 0x100, 0x0, 0x0, 0x202, 0x2, 0x502, 0x202, 0x5, 0x200, 0x1, 0x203, 0x403, 0x103, 0x100, 0x0, 0x3, 0x0,  };
static const uint16 kSpr0EB_UnusedSprite_DATA_05CA08[2] = { 0x400, 0x400,  };
static const uint16 kSpr0EB_UnusedSprite_DATA_05CA0C[2] = { 0x0, 0x100,  };
static const uint16 kSpr0EB_UnusedSprite_DATA_05CA10[3] = { 0x100, 0x140, 0xe0,  };
static const uint16 kSpr0F1_UnusedSprite_DATA_05CA16[4] = { 0x5, 0x500, 0x205, 0x502,  };
static const uint16 kSpr0F1_UnusedSprite_DATA_05CA1E[4] = { 0x0, 0x100, 0x302, 0x304,  };
static const uint16 kSpr0F1_UnusedSprite_DATA_05CA26[12] = { 0x1, 0x101, 0x600, 0x600, 0x0, 0x100, 0x100, 0x8, 0x800, 0x0, 0x100, 0x1,  };
static const uint16 kSpr0EF_Layer2ScrollSOrL_DATA_05CA3E[2] = { 0x800, 0x800,  };
static const uint16 kSpr0EF_Layer2ScrollSOrL_DATA_05CA42[2] = { 0x0, 0x100,  };
static const uint16 kSpr0EF_Layer2ScrollSOrL_DATA_05CA46[1] = { 0x101,  };
static const uint16 kSpr0EA_Layer2Scroll_DATA_05CA48[5] = { 0x300, 0x300, 0x300, 0x300, 0x300,  };
static const uint16 kSpr0EA_Layer2Scroll_DATA_05CA52[5] = { 0x0, 0x100, 0x200, 0x300, 0x400,  };
static const uint16 kSpr0EA_Layer2Scroll_DirectionToStartMoving[2] = { 0x1, 0x0,  };
static const uint8 kSpr0E7_SpecialAutoScroll_DATA_05CA61[7] = { 0x1, 0x18, 0x1e, 0x29, 0x2d, 0x35, 0x47,  };
static const uint8 kSpr0E7_SpecialAutoScroll_DATA_05CA68[7] = { 0x16, 0x5, 0xa, 0x3, 0x7, 0x11, 0x9,  };
static const uint8 kLayer1SpecialScrolling01_VariableScroll_DATA_05CA6F[80] = { 0x0, 0x9, 0x14, 0x1c, 0x24, 0x28, 0x33, 0x3c, 0x43, 0x4b, 0x54, 0x60, 0x67, 0x74, 0x77, 0x7b, 0x83, 0x8a, 0x8d, 0x90, 0x99, 0xa0, 0xb0, 0x0, 0x9, 0x14, 0x2c, 0x3c, 0xb0, 0x0, 0x9, 0x11, 0x1d, 0x2c, 0x32, 0x41, 0x48, 0x63, 0x6b, 0x70, 0x0, 0x27, 0x37, 0x70, 0x0, 0x7, 0x12, 0x27, 0x32, 0x48, 0x5b, 0x70, 0x0, 0x20, 0x28, 0x3a, 0x40, 0x5f, 0x66, 0x6b, 0x6b, 0x80, 0x80, 0x89, 0x92, 0x96, 0x9a, 0x9e, 0xa0, 0xb0, 0x0, 0x10, 0x1a, 0x20, 0x2b, 0x30, 0x3b, 0x40, 0x4b, 0x50,  };
static const uint8 kLayer1SpecialScrolling01_VariableScroll_DATA_05CABF[80] = { 0xc, 0xc, 0x6, 0xb, 0x8, 0xc, 0x3, 0x2, 0x9, 0x3, 0x9, 0x2, 0x6, 0x6, 0x7, 0x5, 0x8, 0x5, 0xa, 0x4, 0x8, 0x4, 0x4, 0xc, 0xc, 0x7, 0x7, 0x5, 0x5, 0xc, 0xc, 0x8, 0xc, 0xc, 0x7, 0x7, 0xa, 0xa, 0xc, 0xc, 0x0, 0x0, 0xa, 0xa, 0x0, 0x0, 0x9, 0x9, 0x3, 0x3, 0xc, 0xc, 0xc, 0xc, 0x8, 0x8, 0x5, 0x5, 0x2, 0x2, 0x9, 0x9, 0x1, 0x1, 0x1, 0x2, 0x3, 0x7, 0x8, 0x8, 0xc, 0xc, 0x2, 0x2, 0xa, 0xa, 0x2, 0x2, 0xa, 0xa,  };
static const uint8 kLayer1SpecialScrolling01_VariableScroll_DATA_05CB0F[80] = { 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x10, 0x8, 0x40, 0x8, 0x4, 0x8, 0x10, 0x8, 0x8, 0x10, 0x10, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8,  };
static const uint8 kLayer1SpecialScrolling01_VariableScroll_DATA_05CB5F[28] = { 0x1, 0x0, 0xff, 0xff, 0x1, 0x0, 0xff, 0xff, 0x1, 0x0, 0xff, 0xff, 0x1, 0x0, 0xff, 0xff, 0x1, 0x0, 0xff, 0xff, 0x1, 0x0, 0xff, 0xff, 0x1, 0x0, 0xff, 0xff,  };
static const uint16 kUnusedScrollSpriteRoutine_DATA_05CB7B[16] = { 0x1, 0xffff, 0x1, 0xffff, 0x1, 0xffff, 0x1, 0xffff, 0x1, 0xffff, 0x1, 0xffff, 0x1, 0xffff, 0x4, 0xfffc,  };
static const uint16 kLayer2SpecialScrolling04_Unused_DATA_05CB9B[4] = { 0x1, 0xffff, 0x1, 0xffff,  };
static const uint16 kLayer2SpecialScrolling0A_Unused_DATA_05CBA3[12] = { 0x4, 0xfffc, 0x4, 0xfffc, 0x4, 0xfffc, 0x4, 0xfffc, 0x1, 0xffff, 0x1, 0xffff,  };
static const uint16 kScrollLayer3_DATA_05CBBB[2] = { 0x4, 0xfffc,  };
static const uint16 kSharedScrollSpriteTables_DATA_05CBC3[2] = { 0x1, 0xffff,  };
static const uint8 kSharedScrollSpriteTables_UNK_05CBC7[28] = { 0x30, 0x70, 0x80, 0x10, 0x28, 0x30, 0x30, 0x30, 0x30, 0x14, 0x2, 0x30, 0x30, 0x30, 0x30, 0x70, 0x80, 0x70, 0x80, 0x70, 0x80, 0x70, 0x80, 0x70, 0x80, 0x70, 0x80, 0x18,  };
static const uint8 kLayer2SpecialScrolling04_Unused_DATA_05CBE3[2] = { 0x18, 0x18,  };
static const uint8 kLayer2SpecialScrolling0A_Unused_DATA_05CBE5[6] = { 0x18, 0x18, 0x8, 0x20, 0x6, 0x6,  };
static const uint8 kScrollLayer3_DATA_05CBEB[2] = { 0x4, 0x4,  };
static const uint8 kSharedScrollSpriteTables_DATA_05CBED[4] = { 0x60, 0x42, 0xd0, 0xb2,  };
static const uint8 kSharedScrollSpriteTables_DATA_05CBF1[4] = { 0x80, 0x80, 0x80, 0x80,  };
static const uint8 kSharedScrollSpriteTables_DATA_05CBF5[10] = { 0x90, 0x72, 0x60, 0x42, 0x20, 0x10, 0x40, 0x22, 0x20, 0x10,  };

// todo: oob
static const uint8 kCourseClearText[76] = { 0x51, 0xd, 0x0, 0x9, 0x30, 0x28, 0x31, 0x28, 0x32, 0x28, 0x33, 0x28, 0x34, 0x28, 0x51, 0x49, 0x0, 0x19, 0xc, 0x38, 0x18, 0x38, 0x1e, 0x38, 0x1b, 0x38, 0x1c, 0x38, 0xe, 0x38, 0xfc, 0x38, 0xc, 0x38, 0x15, 0x38, 0xe, 0x38, 0xa, 0x38, 0x1b, 0x38, 0x28, 0x38, 0x51, 0xa9, 0x0, 0x19, 0x76, 0x38, 0xfc, 0x38, 0xfc, 0x38, 0xfc, 0x38, 0x26, 0x38, 0x5, 0x38, 0x0, 0x38, 0x77, 0x38, 0xfc, 0x38, 0xfc, 0x38, 0xfc, 0x38, 0xfc, 0x38, 0xfc, 0x38, 0xff, 0x40 };

static const uint8 kCourseClearText_Luigi[5] = { 0x40, 0x41, 0x42, 0x43, 0x44,  };
static const uint8 kGotBonusStarsText_Bonus[35] = { 0x52, 0xa, 0x0, 0x15, 0xb, 0x38, 0x18, 0x38, 0x17, 0x38, 0x1e, 0x38, 0x1c, 0x38, 0x28, 0x38, 0xfc, 0x38, 0x64, 0x28, 0x26, 0x38, 0xfc, 0x38, 0xfc, 0x38, 0x51, 0xf3, 0x0, 0x3, 0xfc, 0x38, 0xfc, 0x38, 0xff,  };
static const uint8 kDisplayCourseClearTextBonusStars_DATA_05CD62[20] = { 0xb7, 0xc3, 0xb8, 0xb9, 0xba, 0xbb, 0xba, 0xbf, 0xbc, 0xbd, 0xbe, 0xbf, 0xc0, 0xc3, 0xc1, 0xb9, 0xc2, 0xc4, 0xb7, 0xc5,  };
static const uint16 kAdjustTimeBonusDisplay_DATA_05CDE9[10] = { 0x0, 0x2710, 0x0, 0x3e8, 0x0, 0x64, 0x0, 0xa, 0x0, 0x1,  };
static const uint16 kCalculateTimeBonusDigits_DATA_05CE3A[4] = { 0x0, 0x64, 0xc8, 0x12c,  };
static const uint8 kCalculateTimeBonusDigits_DATA_05CE42[10] = { 0x0, 0xa, 0x14, 0x1e, 0x28, 0x32, 0x3c, 0x46, 0x50, 0x5a,  };
static const uint8 kNoBonusStarsText_Stars[32] = { 0x51, 0xb1, 0x0, 0x9, 0xfc, 0x38, 0xfc, 0x38, 0xfc, 0x38, 0xfc, 0x38, 0x0, 0x38, 0x51, 0xf3, 0x0, 0x3, 0xfc, 0x38, 0xfc, 0x38, 0x52, 0x13, 0x0, 0x3, 0xfc, 0x38, 0xfc, 0x38, 0xff, 10 };
static const uint8 kGiveTimeBonusAndBonusStars_DATA_05CEC2[4] = { 0xa, 0x0, 0x64, 0x0,  };
static const uint8 kGiveTimeBonusAndBonusStars_DATA_05CEC6[4] = { 0x1, 0x0, 0xa, 0x0,  };
static const uint8 kLoadLevel_DATA_05D708[4] = { 0x0, 0x60, 0xc0, 0x0,  };
static const uint8 kLoadLevel_DATA_05D70C[4] = { 0x60, 0x90, 0xc0, 0x0,  };
static const uint8 kLoadLevel_L2VertScrollSettings[8] = { 0x3, 0x1, 0x1, 0x0, 0x0, 0x2, 0x2, 0x1,  };
static const uint8 kLoadLevel_L2HorzScrollSettings[8] = { 0x2, 0x2, 0x1, 0x0, 0x1, 0x2, 0x1, 0x0,  };
static const uint8 kLoadLevel_DATA_05D730[16] = { 0x0, 0x30, 0x60, 0x80, 0xa0, 0xb0, 0xc0, 0xe0, 0x10, 0x30, 0x50, 0x60, 0x70, 0x90, 0x0, 0x0,  };
static const uint8 kLoadLevel_DATA_05D740[16] = { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1,  };
static const uint8 kLoadLevel_DATA_05D750[8] = { 0x10, 0x80, 0x0, 0xe0, 0x10, 0x70, 0x0, 0xe0,  };
static const uint8 kLoadLevel_DATA_05D758[8] = { 0x0, 0x0, 0x0, 0x0, 0x1, 0x1, 0x1, 0x1,  };
static const uint8 kLoadLevel_LevelEntranceTileset[6] = { 0x5, 0x1, 0x2, 0x6, 0x8, 0x1,  };
static const uint8 kLoadLevel_LevelEntranceLayer3[6] = { 0x3, 0x0, 0x0, 0x0, 0x0, 0x0,  };
static const uint8 kLoadLevel_LevelEntranceYPos[6] = { 0x70, 0x70, 0x60, 0x70, 0x70, 0x70,  };
static const uint16 kChoclateIsland2_SpritePtrs[9] = { 0xd899, 0xd8a1, 0xd8a1, 0xd7e5, 0xd7ea, 0xd825, 0xd84b, 0xd86e, 0xd888,  };
static const uint8 kLoadLevel_BonusLevelSublevelsLo[3] = { 0x0, 0xc8, 0x0,  };
static const uint8 kLoadOverworldLifeCounter_DATA_05DBC9[9] = { 0x50, 0x88, 0x0, 0x3, 0xfe, 0x38, 0xfe, 0x38, 0xff,  };

void LoadSublevel() {  // 05801e
  for (uint16 i = 0; i != 512; ++i) {
    blocks_layer2_tiles_lo[i] = 37;
    blocks_layer2_tiles_lo[i + 512] = 37;
  }
  blocks_screen_to_place_current_object = 0;
  lm_varB = ptr_layer2_is_bg;
  if (ptr_layer2_is_bg & 2) {
    if (!(ptr_layer2_is_bg & 4)) {
      uint8 v1 = ptr_layer2_is_bg >> 4;
      for (uint16 j = 0; j != 1024; ++j)
        blocks_layer2_tiles_hi[j] = v1;
    }
    unusedram_copy_of_level_tileset_setting = 0;
    misc_level_tileset_setting = 0;
    BufferBGTilemap(g_ram + 0xb900);
  }
  for (uint16 k = 0; k != 512; k++) {
    InitializeLevelData_Hi(k, 0);
    InitializeLevelData_Lo(k, 0x25);
  }
  blocks_screen_to_place_current_object = 0;
  BeginLoadingLevelData();
  if (sign8(misc_game_mode - 34))
    LoadSublevel_02A751();
}

void InitializeLevelLayer1And2Tilemaps() {  // 05809e
  blocks_screen_to_place_current_object = 0;
  camera_xy_layer1_vramupd_left_up = -1;
  camera_xy_layer1_vramupd_right_down = -1;
  if (g_lunar_magic)
    LmHook_InitializeLevelLayer1And2Tilemaps();
  CalculateRowOrColumnOfTilemapToUpdate();
  camera_layer1_row_column_to_update_right_down = camera_layer1_row_column_to_update_left_up;
  camera_layer2_row_column_to_update_right_down = camera_layer2_row_column_to_update_left_up;
  *(uint16 *)&camera_layer1_scrolling_direction = 514;
  do {
    if (g_lunar_magic) {
      LmHook_BufferTilemap_L1();
      LmHook_BufferTilemap_L2();
      LmHook_UploadLevelLayer1And2Tilemaps();
      ++camera_layer1_row_column_to_update_right_down;
      ++camera_layer2_row_column_to_update_right_down;
    } else {
      BufferScrollingTiles_Layer1_Init();
      BufferScrollingTiles_Layer2_Init();
      UploadLevelLayer1And2Tilemaps();
      ++camera_layer1_row_column_to_update_right_down;
      ++camera_layer2_row_column_to_update_right_down;
      uint16 v0 = 614;
      uint16 R0_W = 7;
      uint16 v1 = kCalculateRowOrColumnOfTilemapToUpdate_PipeMap16Ptrs[(camera_layer1_row_column_to_update_right_down >> 4) & 3];
      do {
        pointer_map16_tiles[v0 >> 1] = v1;
        v0 += 2;
        v1 += 8;
      } while ((--R0_W & 0x8000) == 0);
    }
    ++blocks_screen_to_place_current_object;
  } while (blocks_screen_to_place_current_object != 32);
  uint8 v2 = mirror_main_screen_layers;
  RtlPpuWrite(TM, mirror_main_screen_layers);
  RtlPpuWrite(TMW, v2);
  uint8 v3 = mirror_sub_screen_layers;
  RtlPpuWrite(TS, mirror_sub_screen_layers);
  RtlPpuWrite(TSW, v3);
  camera_xy_layer1_vramupd_left_up = -1;
  camera_xy_layer1_vramupd_right_down = -1;
  camera_xy_layer2_vramupd_left_up = -1;
  camera_xy_layer2_vramupd_right_down = -1;
}

void BufferBGTilemap(uint8 *r13) {  // 058126
  const uint8 *p = ptr_layer2_data; 
  uint16 R3 = 0;
  uint16 R5_W = 0;
  do {
    uint8 r7 = p[R3++];
    if ((r7 & 0x80) == 0) {
      do {
        uint8 v5 = p[R3++];
        r13[R5_W++] = v5;
      } while ((--r7 & 0x80) == 0);
    } else {
      r7 &= ~0x80;
      uint8 v2 = p[R3++];
      do {
        r13[R5_W++] = v2;
      } while ((--r7 & 0x80) == 0);
    }
  } while (p[R3] != 0xFF || p[R3 + 1] != 0xFF);
  uint16 R0_W = 0x9100;  // kMap16Data_Backgrounds
  for (uint16 i = 0; i != 0x400; i += 2) {
    pointer_map16_tiles[i >> 1] = R0_W;
    R0_W += 8;
  }
}

void InitializeMap16Pointers() {  // 0581fb
  ptr_slope_steepness.bank = 0;
  blocks_lowest_number_solid_map16_tile_for_sprites = -60;
  blocks_highest_number_solid_map16_tile_for_sprites = -54;
  ptr_slope_steepness.addr = 0xe55e;
  uint16 R0_W = kInitializeMap16Pointers_TilesetMap16Ptrs[misc_level_tileset_setting];
  uint16 R2_W = 0x8000;  // bank 0xD
  const uint8 *r13 = kInitializeMap16Pointers_DATA_0581BB;
//  R4_W = 0;
//  R9_ = 0;
  uint8 r11 = 0;
  uint16 v0 = 0;
  uint16 v1 = 0;
  do {
    uint16 r12 = r13[v0];
    do {
      bool v2 = __CFSHL__(r12, 1);
      r12 *= 2;
      if (v2) {
        pointer_map16_tiles[v1 >> 1] = R2_W;
        R2_W += 8;
      } else {
        pointer_map16_tiles[v1 >> 1] = R0_W;
        R0_W += 8;
      }
      v1 += 2;
//      ++R9_;
    } while (++r11 != 8);
    r11 = 0;
    ++v0;
  } while (v0 != 64);
  if (!misc_level_tileset_setting || misc_level_tileset_setting == 7) {
    blocks_lowest_number_solid_map16_tile_for_sprites = -1;
    blocks_highest_number_solid_map16_tile_for_sprites = -1;
    ptr_slope_steepness.addr = 0xe5c8;
    uint16 v3 = 904;
    R0_W = 0x8a70;
    for (int16 i = 3; i >= 0; --i) {
      pointer_map16_tiles[v3 >> 1] = R0_W;
      R0_W = R0_W + 8;
      v3 += 2;
    }
    uint16 v6 = 984;
    for (int16 j = 3; j >= 0; --j) {
      pointer_map16_tiles[v6 >> 1] = R0_W;
      R0_W = R0_W + 8;
      v6 += 2;
    }
  }
}

uint16 InitializeLevelData_Lo(uint16 k, uint8 a) {  // 0582c8
  blocks_map16_table_lo[k] = a;
  blocks_map16_table_lo[k + 512] = a;
  blocks_map16_table_lo[k + 0x400] = a;
  blocks_map16_table_lo[k + 0x600] = a;
  ow_level_number_of_each_tiletbl[k] = a;
  ow_level_number_of_each_tiletbl[k + 512] = a;
  ow_level_number_of_each_tiletbl[k + 0x400] = a;
  ow_level_number_of_each_tiletbl[k + 0x600] = a;
  ow_level_direction_flags[k] = a;
  ow_level_direction_flags[k + 512] = a;
  ow_level_direction_flags[k + 0x400] = a;
  ow_level_direction_flags[k + 0x600] = a;
  ow_byte_7EE000[k] = a;
  ow_byte_7EE000[k + 512] = a;
  ow_byte_7EE000[k + 0x400] = a;
  ow_byte_7EE000[k + 0x600] = a;
  ow_byte_7EE000[k + 0x800] = a;
  ow_byte_7EE000[k + 0xa00] = a;
  ow_byte_7EE000[k + 0xc00] = a;
  ow_byte_7EE000[k + 0xe00] = a;
  ow_byte_7EE000[k + 0x1000] = a;
  ow_byte_7EE000[k + 0x1200] = a;
  ow_byte_7EE000[k + 0x1400] = a;
  ow_byte_7EE000[k + 0x1600] = a;
  ow_byte_7EE000[k + 0x1800] = a;
  ow_byte_7EE000[k + 0x1a00] = a;
  ow_byte_7EE000[k + 0x1c00] = a;
  ow_byte_7EE000[k + 0x1e00] = a;
  return k + 1;
}

uint16 InitializeLevelData_Hi(uint16 k, uint8 a) {  // 05833a
  blocks_map16_table_hi[k] = a;
  blocks_map16_table_hi[k + 512] = a;
  blocks_map16_table_hi[k + 0x400] = a;
  blocks_map16_table_hi[k + 0x600] = a;
  blocks_map16_table_hi[k + 0x800] = a;
  blocks_map16_table_hi[k + 0xa00] = a;
  blocks_map16_table_hi[k + 0xc00] = a;
  blocks_map16_table_hi[k + 0xe00] = a;
  blocks_map16_table_hi[k + 0x1000] = a;
  blocks_map16_table_hi[k + 0x1200] = a;
  blocks_map16_table_hi[k + 0x1400] = a;
  blocks_map16_table_hi[k + 0x1600] = a;
  blocks_map16_table_hi[k + 0x1800] = a;
  blocks_map16_table_hi[k + 0x1a00] = a;
  blocks_map16_table_hi[k + 0x1c00] = a;
  blocks_map16_table_hi[k + 0x1e00] = a;
  blocks_map16_table_hi[k + 0x2000] = a;
  blocks_map16_table_hi[k + 0x2200] = a;
  blocks_map16_table_hi[k + 0x2400] = a;
  blocks_map16_table_hi[k + 0x2600] = a;
  blocks_map16_table_hi[k + 0x2800] = a;
  blocks_map16_table_hi[k + 0x2a00] = a;
  blocks_map16_table_hi[k + 0x2c00] = a;
  blocks_map16_table_hi[k + 0x2e00] = a;
  blocks_map16_table_hi[k + 0x3000] = a;
  blocks_map16_table_hi[k + 0x3200] = a;
  blocks_map16_table_hi[k + 0x3400] = a;
  blocks_map16_table_hi[k + 0x3600] = a;
  return k + 1;
}

extern Snes *g_snes;
void BeginLoadingLevelData() {  // 0583ac
  if (g_lunar_magic)
    LmHook_InitExanimForLevel();

  LOBYTE(misc_current_layer_being_processed) = 0;
  LoadLevelHeader();
  InitializeMap16Pointers();
  for(;;) {
    if (g_lunar_magic)
      LmHook_BeginLoadingLevelDataB();
    if (misc_level_mode_setting == 9 || misc_level_mode_setting == 11 || misc_level_mode_setting == 16)
      break;
    if (*ptr_layer1_data != 0xFF)
      LoadLevelDataObject();
    if (misc_level_mode_setting == 0 || misc_level_mode_setting == 10 || misc_level_mode_setting == 12 ||
        misc_level_mode_setting == 13 || misc_level_mode_setting == 14 || misc_level_mode_setting == 17 || misc_level_mode_setting == 30) 
      break;
    LOBYTE(misc_current_layer_being_processed) = misc_current_layer_being_processed + 1;
    if ((uint8)misc_current_layer_being_processed == 2)
      break;
    ptr_layer1_data = ptr_layer2_data + 5;
    blocks_screen_to_place_current_object = 0;
  }
  LOBYTE(misc_current_layer_being_processed) = 0;
}

void LoadLevelHeader() {  // 0584e3
  const uint8 *hdr = ptr_layer1_data;
  uint8 v0 = hdr[0];
  misc_screens_in_lvl = (v0 & 0x1F) + 1;
  misc_bgpalette_setting = v0 >> 5;
  misc_level_mode_setting = hdr[1] & 0x1F;
  sprites_tile_priority = kLoadLevelHeader_LevXYPPCCCTtbl[misc_level_mode_setting];
  mirror_main_screen_layers = kLoadLevelHeader_LevMainScrnTbl[misc_level_mode_setting];
  mirror_sub_screen_layers = kLoadLevelHeader_LevSubScrnTbl[misc_level_mode_setting];
  mirror_color_math_select_and_enable = kLoadLevelHeader_LevCGADSUBtable[misc_level_mode_setting];
  misc_nmito_use_flag = kLoadLevelHeader_SpecialLevTable[misc_level_mode_setting];
  misc_level_layout_flags = kLoadLevelHeader_VerticalTable[misc_level_mode_setting];
  uint8 v1 = misc_screens_in_lvl;
  uint8 v2 = 1;
  if (misc_level_layout_flags & 1) {
    v2 = misc_screens_in_lvl;
    v1 = 1;
  }
  camera_last_screen_horiz = v1;
  camera_last_screen_vert = v2;
  misc_background_color_setting = hdr[1] >> 5;
  uint8 r0 = hdr[2];
  graphics_level_sprite_graphics_setting = r0 & 0xF;
  uint8 v3 = kLoadLevelHeader_LevelMusicTable[(r0 >> 4) & 7];
  if (HAS_LM_FEATURE(kLmFeature_MusicRegTweak)) {
    if (misc_game_mode >= 7)
      misc_music_register_backup = v3;
  } else {
    if ((misc_music_register_backup & 0x80) != 0)
      v3 |= 0x80;
    if (v3 == misc_music_register_backup)
      v3 |= 0x40;
    misc_music_register_backup = v3;
  }
  mirror_bgmode_and_tile_size_setting = ((uint8)(r0 & 0x80) >> 4) | 1;
  r0 = hdr[3];
  if (!counter_sublevels_entered) {
    counter_timer_hundreds = kLoadLevelHeader_TimerTable[r0 >> 6];
    if (HAS_LM_FEATURE(kLmFeature_TimerTweaks))
      lm_timer_var = counter_timer_hundreds;
    counter_timer_tens = 0;
    counter_timer_ones = 0;
  }
  misc_fgpalette_setting = r0 & 7;
  misc_sprite_palette_setting = (uint8)(r0 & 0x38) >> 3;
  misc_level_tileset_setting = hdr[4] & 0xF;
  unusedram_copy_of_level_tileset_setting = misc_level_tileset_setting;
  int8 v4 = hdr[4] & 0xC0;
  misc_item_memory_setting = 2 * (4 * v4 + __CFSHL__(v4, 1)) + __CFSHL__(2 * v4, 1);
  uint8 v5 = (uint8)(hdr[4] & 0x30) >> 4;
  if (v5 == 3) {
    flag_layer1_horiz_scroll_level_setting = 0;
    v5 = 0;
  }
  flag_layer1_vert_scroll_level_setting = v5;
  ptr_layer1_data += 5;
}

void LoadLevelDataObject() {  // 0585ff
  const uint8 *hdr;
  do {
    hdr = ptr_layer1_data;
    uint8 b0 = hdr[0];
    uint8 b1 = hdr[1];
    blocks_size_or_type = hdr[2];
    ptr_layer1_data += 3;

    blocks_object_number = (b1 >> 4) | ((b0 & 0x60) >> 1);
    int8 v1 = misc_level_layout_flags;
    if ((uint8)misc_current_layer_being_processed)
      v1 = misc_level_layout_flags >> 1;
    if ((v1 & 1) != 0) {
      if (__PAIR16__(blocks_object_number, blocks_size_or_type) >= 2) {
        uint8 r0 = b0 & 0xF;
        b0 = b1 & 0xF | b0 & 0xF0;
        b1 = r0 | b1 & 0xF0;
      }
    }
    blocks_sub_scr_pos = 16 * (b0 & 0xF);
    blocks_sub_scr_pos |= b1 & 0xF;
    int v2 = misc_current_layer_being_processed;
    uint8 v3 = misc_level_mode_setting & 0x1F;

    const uint16 *r0 = GetLayerLayoutPtr(v2, v3);

    blocks_screen_to_place_current_object += (b0 & 0x80) != 0;
    blocks_screen_to_place_next_object = blocks_screen_to_place_current_object;
    ptr_lo_map16_data = g_ram + r0[blocks_screen_to_place_current_object];
    if ((b0 & 0x10) != 0) {
      ptr_lo_map16_data += 256;
    }
    loadlvl_R10 = b0;
    loadlvl_R11 = b1;
    if (blocks_object_number)
      ProcessStandardAndTilesetSpecificObjects();
    else
      ProcessExtendedObjects();
  } while (*ptr_layer1_data != 0xff);
}

void CheckIfLevelTilemapsNeedScrollUpdate() {  // 0586f1
  uint16 v0, v1, v2, v3;
  CalculateRowOrColumnOfTilemapToUpdate();
  if (g_lunar_magic) {
    LmHook_CheckIfLevelTilemapsNeedScrollUpdate();
    return;
  }

  if ((misc_level_layout_flags & 1) != 0) {
    v0 = camera_layer1_scrolling_direction;
    v1 = mirror_current_layer1_ypos & 0xFFF0;
    if ((mirror_current_layer1_ypos & 0xFFF0) !=
        *(uint16 *)((int8 *)&camera_xy_layer1_vramupd_left_up + camera_layer1_scrolling_direction)) {
LABEL_5:
      *(uint16 *)((int8 *)&camera_xy_layer1_vramupd_left_up + v0) = v1;
      *(uint16 *)((int8 *)&camera_xy_layer1_vramupd_left_up + (v0 ^ 2)) = -1;
      BufferScrollingTiles_Layer1_Main();
      return;
    }
  } else {
    v0 = camera_layer1_scrolling_direction;
    v1 = mirror_current_layer1_xpos & 0xFFF0;
    if ((mirror_current_layer1_xpos & 0xFFF0) !=
        *(uint16 *)((int8 *)&camera_xy_layer1_vramupd_left_up + camera_layer1_scrolling_direction))
      goto LABEL_5;
  }
  if ((misc_level_layout_flags & 2) != 0) {
    v2 = camera_layer2_scrolling_direction;
    v3 = mirror_current_layer2_ypos & 0xFFF0;
    if ((mirror_current_layer2_ypos & 0xFFF0) ==
        *(uint16 *)((int8 *)&camera_xy_layer2_vramupd_left_up + camera_layer2_scrolling_direction))
      return;
  } else {
    v2 = camera_layer2_scrolling_direction;
    v3 = mirror_current_layer2_xpos & 0xFFF0;
    if ((mirror_current_layer2_xpos & 0xFFF0) ==
        *(uint16 *)((int8 *)&camera_xy_layer2_vramupd_left_up + camera_layer2_scrolling_direction))
      return;
  }
  *(uint16 *)((int8 *)&camera_xy_layer2_vramupd_left_up + v2) = v3;
  *(uint16 *)((int8 *)&camera_xy_layer2_vramupd_left_up + (v2 ^ 2)) = -1;
  BufferScrollingTiles_Layer2_Main();
}

void CalculateRowOrColumnOfTilemapToUpdate() {  // 05877e
  if ((misc_level_layout_flags & 1) != 0) {
    camera_layer1_row_column_to_update_left_up = (mirror_current_layer1_ypos >> 4) - 8;
    camera_layer1_row_column_to_update_right_down = (mirror_current_layer1_ypos >> 4) + 23;
  } else {
    camera_layer1_row_column_to_update_left_up = (mirror_current_layer1_xpos >> 4) - 8;
    camera_layer1_row_column_to_update_right_down = (mirror_current_layer1_xpos >> 4) + 23;

    if (!g_lunar_magic) {
      uint16 v0 = (*((uint8 *)&camera_layer1_row_column_to_update_left_up + camera_layer1_scrolling_direction) >> 3) & 6;
      uint16 v1 = 614;
      uint16 R0_W = 7;
      uint16 v2 = kCalculateRowOrColumnOfTilemapToUpdate_PipeMap16Ptrs[v0 >> 1];
      do {
        pointer_map16_tiles[v1 >> 1] = v2;
        v1 += 2;
        v2 += 8;
      } while ((--R0_W & 0x8000) == 0);
    }
  }
  if ((misc_level_layout_flags & 2) != 0) {
    camera_layer2_row_column_to_update_left_up = (mirror_current_layer2_ypos >> 4) - 8;
    camera_layer2_row_column_to_update_right_down = (mirror_current_layer2_ypos >> 4) + 23;
  } else {
    camera_layer2_row_column_to_update_left_up = (mirror_current_layer2_xpos >> 4) - 8;
    camera_layer2_row_column_to_update_right_down = (mirror_current_layer2_xpos >> 4) + 23;
  }
}

void BufferScrollingTiles_Layer1_Main() {  // 05881a
  kBufferScrollingTiles_Layer1_Main_PtrsLong058823[misc_level_mode_setting]();
}

void BufferScrollingTiles_Layer2_Main() {  // 058883
  kBufferScrollingTiles_Layer2_Main_PtrsLong05888C[misc_level_mode_setting]();
}

void BufferScrollingTiles_Layer1_Init() {  // 0588ec
  kBufferScrollingTiles_Layer1_Init_PtrsLong0588F5[misc_level_mode_setting]();
}

void BufferScrollingTiles_Layer2_Init() {  // 058955
  kBufferScrollingTiles_Layer2_Init_PtrsLong05895E[misc_level_mode_setting]();
}

static const uint16 kLevelDataLayout_StdHoriz[] = {
  0xc800, 0xc9b0, 0xcb60, 0xcd10, 0xcec0, 0xd070, 0xd220, 0xd3d0, 0xd580, 0xd730, 0xd8e0, 0xda90, 0xdc40, 0xddf0, 0xdfa0, 0xe150,
  0xe300, 0xe4b0, 0xe660, 0xe810, 0xe9c0, 0xeb70, 0xed20, 0xeed0, 0xf080, 0xf230, 0xf3e0, 0xf590, 0xf740, 0xf8f0, 0xfaa0, 0xfc50
};

static const uint16 kLevelDataLayout_VertL1HorizL2[] = {
  0xc800, 0xca00, 0xcc00, 0xce00, 0xd000, 0xd200, 0xd400, 0xd600, 0xd800, 0xda00, 0xdc00, 0xde00, 0xe000, 0xe200,
  0xe300, 0xe4b0, 0xe660, 0xe810, 0xe9c0, 0xeb70, 0xed20, 0xeed0, 0xf080, 0xf230, 0xf3e0, 0xf590, 0xf740, 0xf8f0, 0xfaa0, 0xfc50,
};

static const uint16 kLevelDataLayout_HorizL1VertL2[] = {
  0xc800, 0xc9b0, 0xcb60, 0xcd10, 0xcec0, 0xd070, 0xd220, 0xd3d0, 0xd580, 0xd730, 0xd8e0, 0xda90, 0xdc40, 0xddf0, 0xdfa0, 0xe150,
  0xe400, 0xe600, 0xe800, 0xea00, 0xec00, 0xee00, 0xf000, 0xf200, 0xf400, 0xf600, 0xf800, 0xfa00, 0xfc00, 0xfe00,
};

static const uint16 kLevelDataLayout_StdVert[] = {
  0xc800, 0xca00, 0xcc00, 0xce00, 0xd000, 0xd200, 0xd400, 0xd600, 0xd800, 0xda00, 0xdc00, 0xde00, 0xe000, 0xe200,
  0xe400, 0xe600, 0xe800, 0xea00, 0xec00, 0xee00, 0xf000, 0xf200, 0xf400, 0xf600, 0xf800, 0xfa00, 0xfc00, 0xfe00,
};

const uint16 *const kLevelDataLayoutTables_Layer1LoPtrs[32] = {
  kLevelDataLayout_StdHoriz,
  kLevelDataLayout_StdHoriz,
  kLevelDataLayout_StdHoriz,
  kLevelDataLayout_VertL1HorizL2,
  kLevelDataLayout_VertL1HorizL2,
  kLevelDataLayout_HorizL1VertL2,
  kLevelDataLayout_HorizL1VertL2,
  kLevelDataLayout_StdVert,
  kLevelDataLayout_StdVert,
  0,
  kLevelDataLayout_StdVert,
  0,
  kLevelDataLayout_StdHoriz,
  kLevelDataLayout_StdVert,
  kLevelDataLayout_StdHoriz,
  kLevelDataLayout_StdHoriz,
  0,
  kLevelDataLayout_StdHoriz,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  kLevelDataLayout_StdHoriz,
  kLevelDataLayout_StdHoriz,
};

static const uint16 *const kLevelDataLayoutTables_Layer2LoPtrs[32] = {
  kLevelDataLayout_StdHoriz + 16,
  kLevelDataLayout_StdHoriz + 16,
  kLevelDataLayout_StdHoriz + 16,
  kLevelDataLayout_VertL1HorizL2 + 14,
  kLevelDataLayout_VertL1HorizL2 + 14,
  kLevelDataLayout_HorizL1VertL2 + 16,
  kLevelDataLayout_HorizL1VertL2 + 16,
  kLevelDataLayout_StdVert + 14,
  kLevelDataLayout_StdVert + 14,
  0,
  kLevelDataLayout_StdVert + 14,
  0,
  kLevelDataLayout_StdHoriz + 16,
  kLevelDataLayout_StdVert + 14,
  kLevelDataLayout_StdHoriz + 16,
  kLevelDataLayout_StdHoriz + 16,
  0,
  kLevelDataLayout_StdHoriz + 16,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  kLevelDataLayout_StdHoriz + 16,
  kLevelDataLayout_StdHoriz + 16,
};

const uint16 *GetLayerLayoutPtr(int layer, int top) {
  return layer ? kLevelDataLayoutTables_Layer2LoPtrs[top] : kLevelDataLayoutTables_Layer1LoPtrs[top];
}

void BufferScrollingTiles_Layer1() {  // 0589ce
  uint16 v0 = camera_layer1_scrolling_direction;
  HIBYTE(blocks_layer1_vramupload_address) = 2 * (*((uint8 *)&camera_layer1_row_column_to_update_left_up + v0) & 0xF);
  int8 v1 = 32;
  if ((*((uint8 *)&camera_layer1_row_column_to_update_left_up + v0) & 0x10) != 0)
    v1 = 36;
  LOBYTE(blocks_layer1_vramupload_address) = v1;
  uint16 lm_mask = g_lunar_magic ? 0x3ff0 : 0x1f0;
  uint16 R0_W = (uint16)(*(uint16 *)((int8 *)&camera_layer1_row_column_to_update_left_up + v0) & lm_mask) >> 4;
  const uint8 *plo = g_ram + kLevelDataLayoutTables_Layer1LoPtrs[misc_level_mode_setting][R0_W];
  uint8 bank = sign8(misc_level_tileset_setting - 16) ? 13 : 5;
  uint16 r8 = *((uint8 *)&camera_layer1_row_column_to_update_left_up + v0) & 0xF;
  uint16 v4 = 0;
  do {
    uint16 v5 = r8;
    R0_W = plo[v5] | plo[v5 + 0x10000] << 8;
    const uint16 *r10t = Lm_GetMap16RomAddr(R0_W);
    int v6 = v4 >> 1;
    blocks_layer1_tiles_to_upload_buffer[v6] = r10t[0];
    blocks_layer1_tiles_to_upload_buffer[v6 + 1] = r10t[1];
    blocks_layer1_tiles_to_upload_buffer[v6 + 64] = r10t[2];
    blocks_layer1_tiles_to_upload_buffer[v6 + 65] = r10t[3];
    v4 += 4;
    r8 += 16;
  } while (r8 < 0x1B0);
}

void BufferScrollingTiles_Layer1_NoScroll() {  // 058a9a
  ;
}

void BufferScrollingTiles_Layer1_VerticalLevel() {  // 058a9b
  int lvl_setting = misc_level_mode_setting;
  int max_n = (lvl_setting == 7 || lvl_setting == 8 || lvl_setting == 10 || lvl_setting == 13) ? 28 : 16;

  const uint16 *r10 = kLevelDataLayoutTables_Layer1LoPtrs[lvl_setting];

  uint16 v0 = camera_layer1_scrolling_direction;
  uint8 v1 = 32;
  if ((*((uint8 *)&camera_layer1_row_column_to_update_left_up + v0) & 0x10) != 0)
    v1 = 40;
  LOBYTE(blocks_layer1_vramupload_address) = v1 | (*((uint8 *)&camera_layer1_row_column_to_update_left_up + v0) >> 2) & 3;
  HIBYTE(blocks_layer1_vramupload_address) = (*((uint8 *)&camera_layer1_row_column_to_update_left_up + v0) & 3) << 6;
  uint16 lm_mask = g_lunar_magic ? 0x3ff0 : 0x1f0;
  uint16 R0_W = (uint16)(*(uint16 *)((int8 *)&camera_layer1_row_column_to_update_left_up + v0) & lm_mask) >> 4;
  uint16 v2 = (R0_W < max_n) ? R0_W : 0;
  const uint8 *plo = g_ram + r10[v2];
  uint8 bank = sign8(misc_level_tileset_setting - 16) ? 13 : 5;
  uint16 r8 = 16 * (*((uint8 *)&camera_layer1_row_column_to_update_left_up + v0) & 0xF);
  uint16 v4 = 0;
  do {
    uint16 v5 = r8;
    R0_W = plo[r8] | plo[v5 + 0x10000] << 8;
    
    const uint16 *r10p = Lm_GetMap16RomAddr(R0_W);
    int v6 = v4 >> 1;
    blocks_layer1_tiles_to_upload_buffer[v6] = r10p[0];
    blocks_layer1_tiles_to_upload_buffer[v6 + 64] = r10p[1];
    uint16 v7 = v4 + 2;
    int v8 = v7 >> 1;
    blocks_layer1_tiles_to_upload_buffer[v8] = r10p[2];
    blocks_layer1_tiles_to_upload_buffer[v8 + 64] = r10p[3];
    v4 = v7 + 2;
    uint16 v9 = r8++;
    if ((r8 & 0xF) == 0)
      r8 = (v9 & 0xFFF0) + 256;
  } while ((r8 & 0x10F) != 0);
}

void BufferScrollingTiles_Layer2() {  // 058b8d
  int16 v1 = 0;
  if (misc_level_tileset_setting == 3)
    v1 = 0x1000;
  uint16 R3_W = v1;

  const uint16 *r10 = kLevelDataLayoutTables_Layer2LoPtrs[misc_level_mode_setting];
  
  uint16 v0 = camera_layer2_scrolling_direction;
  HIBYTE(blocks_layer2_vramupload_address) = 2 * (*((uint8 *)&camera_layer2_row_column_to_update_left_up + v0) & 0xF);
  int8 v2 = 48;
  if ((*((uint8 *)&camera_layer2_row_column_to_update_left_up + v0) & 0x10) != 0)
    v2 = 52;
  LOBYTE(blocks_layer2_vramupload_address) = v2;
  uint16 lm_mask = g_lunar_magic ? 0x3ff0 : 0x1f0;
  uint16 R0_W = (uint16)(*(uint16 *)((int8 *)&camera_layer2_row_column_to_update_left_up + v0) & lm_mask) >> 4;
  const uint8 *plo = g_ram + r10[R0_W];

  uint8 bank = sign8(misc_level_tileset_setting - 16) ? 13 : 5;
  uint16 r8 = *((uint8 *)&camera_layer2_row_column_to_update_left_up + v0) & 0xF;
  uint16 v5 = 0;
  do {
    uint16 v6 = r8;
    R0_W = plo[r8] | plo[v6 + 0x10000] << 8;
    const uint16 *r10w = Lm_GetMap16RomAddr(R0_W);
    int v7 = v5 >> 1;
    blocks_layer2_tiles_to_upload_buffer[v7] = R3_W | r10w[0];
    blocks_layer2_tiles_to_upload_buffer[v7 + 1] = R3_W | r10w[1];
    blocks_layer2_tiles_to_upload_buffer[v7 + 64] = R3_W | r10w[2];
    blocks_layer2_tiles_to_upload_buffer[v7 + 65] = R3_W | r10w[3];
    v5 += 4;
    r8 += 16;
  } while (r8 < 0x1B0);
}

void BufferScrollingTiles_Layer2_NoScroll() {  // 058c70
  ;
}

void BufferScrollingTiles_Layer2_VerticalLevel() {  // 058c71
  int lvl_setting = misc_level_mode_setting;
  int max_n = (lvl_setting == 7 || lvl_setting == 8 || lvl_setting == 10 || lvl_setting == 13) ? 28 : 16;

  int16 v2 = 0;
  if (misc_level_tileset_setting == 3)
    v2 = 0x1000;
  uint16 R3_W = v2;

  const uint16 *r10 = kLevelDataLayoutTables_Layer2LoPtrs[misc_level_mode_setting];

  uint16 v1 = camera_layer2_scrolling_direction;
  uint8 v3 = 48;
  if ((*((uint8 *)&camera_layer2_row_column_to_update_left_up + v1) & 0x10) != 0)
    v3 = 56;
  LOBYTE(blocks_layer2_vramupload_address) = v3 | (*((uint8 *)&camera_layer2_row_column_to_update_left_up + v1) >> 2) & 3;
  HIBYTE(blocks_layer2_vramupload_address) = (*((uint8 *)&camera_layer2_row_column_to_update_left_up + v1) & 3) << 6;
  uint16 lm_mask = g_lunar_magic ? 0x3ff0 : 0x1f0;
  uint16 R0_W = (uint16)(*(uint16 *)((int8 *)&camera_layer2_row_column_to_update_left_up + v1) & lm_mask) >> 4;
  uint16 v4 = (R0_W < max_n) ? R0_W : 0;
  const uint8 *plo = g_ram + r10[v4];
  uint8 bank = sign8(misc_level_tileset_setting - 16) ? 13 : 5;
  uint16 r8 = 16 * (*((uint8 *)&camera_layer2_row_column_to_update_left_up + v1) & 0xF);
  uint16 v6 = 0;
  do {
    uint16 v7 = r8;
    R0_W = plo[r8] | plo[r8 + 0x10000] << 8;
    const uint16 *r10w = Lm_GetMap16RomAddr(R0_W);
    int v8 = v6 >> 1;
    blocks_layer2_tiles_to_upload_buffer[v8] = R3_W | r10w[0];
    blocks_layer2_tiles_to_upload_buffer[v8 + 64] = R3_W | r10w[1];
    uint16 v9 = v6 + 2;
    int v10 = v9 >> 1;
    blocks_layer2_tiles_to_upload_buffer[v10] = R3_W | r10w[2];
    blocks_layer2_tiles_to_upload_buffer[v10 + 64] = R3_W | r10w[3];
    v6 = v9 + 2;
    uint16 v11 = r8++;
    if ((r8 & 0xF) == 0)
      r8 = (v11 & 0xFFF0) + 256;
  } while ((r8 & 0x10F) != 0);
}

void BufferScrollingTiles_Layer2_Background() {  // 058d7a
  HIBYTE(blocks_layer2_vramupload_address) = 2 * (blocks_screen_to_place_current_object & 0xF);
  int8 v0 = 48;
  if ((blocks_screen_to_place_current_object & 0x10) != 0)
    v0 = 52;
  LOBYTE(blocks_layer2_vramupload_address) = v0;
  const uint8 *phi = g_ram + 0xbd00, *plo = g_ram + 0xb900;

  //;  // kMap16Data_Backgrounds
  const uint8 *r10 = (const uint8 *)kMap16Data + 0x1100;
  if (g_lunar_magic)
    r10 = (uint8*)LmHook_CustomBgMap16();

  if ((blocks_screen_to_place_current_object & 0xF0) != 0) {
    plo += 432;
    phi += 432;
  }
  
  uint16 r8 = blocks_screen_to_place_current_object & 0xF;
  uint16 v1 = 0;
  do {
    uint16 v2 = r8;
    uint16 R0_W = plo[r8] | phi[v2] << 8;
    uint16 v3 = 8 * R0_W;
    int v4 = v1 >> 1;
    blocks_layer2_tiles_to_upload_buffer[v4] = *(uint16 *)(r10 + v3);
    v3 += 2;
    blocks_layer2_tiles_to_upload_buffer[v4 + 1] = *(uint16 *)(r10 + v3);
    v3 += 2;
    blocks_layer2_tiles_to_upload_buffer[v4 + 64] = *(uint16 *)(r10 + v3);
    blocks_layer2_tiles_to_upload_buffer[v4 + 65] = *(uint16 *)(r10 + v3 + 2);
    v1 += 4;
    r8 += 16;
  } while (r8 < 0x1B0);
}


void DisplayMessage() {  // 05b10c
  int16 v7;

  if (timer_wait_before_message_window_size_change == kDisplayMessage_DATA_05B108[flag_message_window_size_change_direction]) {
    if (flag_message_window_size_change_direction) {
      misc_display_message = 0;
      flag_message_window_size_change_direction = 0;
      mirror_bg1_and2_window_mask_settings = 0;
      mirror_bg3_and4_window_mask_settings = 0;
      mirror_object_and_color_window_settings = 0;
      mirror_hdmaenable = 0;
      mirror_color_math_initial_settings = 2;
      return;
    }
    if ((misc_color_of_palace_switch_pressed1 | misc_intro_level_flag) && timer_title_screen_input_timer) {
      if ((counter_global_frames & 3) != 0)
        return;
      if (--timer_title_screen_input_timer)
        return;
      if (misc_color_of_palace_switch_pressed1) {
        ++counter_enemy_rollcall_screen;
        flag_got_midpoint = 1;
        sub_5B165(1);
        return;
      }
    }
    if ((io_controller_hold1 & 0xF0) != 0 &&
        (((io_controller_press1 ^ io_controller_hold1 & 0xF0) & 0xF0) == 0 ||
         (io_controller_hold2 & 0xC0) != 0 && ((io_controller_press2 ^ io_controller_hold2 & 0xC0) & 0xC0) == 0)) {
      if (misc_intro_level_flag) {
        if (!HAS_LM_FEATURE(kLmFeature_DontSetYposForIntroMarch))
          LOBYTE(get_PointU16(ow_players_pos, 0)->y) = -114;
        DisplayMessage_ExitToOverworldNoEvent();
      } else {
        ++flag_message_window_size_change_direction;
      }
    }
  } else {
    if (timer_wait_before_message_window_size_change == kDisplayMessage_DATA_05B106[flag_message_window_size_change_direction]) {
      if (flag_message_window_size_change_direction) {
        DisplayMessage_RemoveSwitchBlocks();
        graphics_stripe_image_to_upload = 9;
      } else if (HAS_LM_FEATURE(kLmFeature_CustomDisplayMessage)) {
        LmHook_DisplayMessage();
      } else {
        uint8 v0 = 22;
        do {
          int8 v1 = 1;
          int8 v2 = kDisplayMessage_DATA_05A590[v0];
          if (v2 < 0) {
            v1 = 2;
            v2 &= ~0x80;
          }
          if (v1 == misc_display_message && v2 == ow_level_number_lo)
            break;
          --v0;
        } while (v0);
        if (misc_display_message == 3)
          v0 = 24;
        if (v0 < 4) {
          misc_color_of_palace_switch_pressed1 = v0 + 1;
          DisplayMessage_DrawSwitchBlocks(v0);
        }
        if (v0 == 22 && player_riding_yoshi_flag)
          v0 = 23;
        uint16 R0_W = kDisplayMessage_DATA_05A5A7[v0];
        uint16 v3 = stripe_image_upload;
        uint16 v4 = 14;
        do {
          *(uint16 *)&stripe_image_upload_data[v3] = kDisplayMessage_DATA_05A580[v4 >> 1];
          *(uint16 *)&stripe_image_upload_data[v3 + 2] = 0x2300;
          uint16 v11 = v4;
          uint8 R2_ = 18;
          uint8 R3_ = 0;
          uint16 v5 = R0_W;
          do {
            uint8 v6 = 31;
            if ((R3_ & 0x80) == 0) {
              R3_ = kDisplayMessage_DATA_05A5D9[v5];
              v6 = R3_ & 0x7F;
              ++v5;
            }
            stripe_image_upload_data[v3 + 4] = v6;
            stripe_image_upload_data[v3 + 5] = 57;
            v3 += 2;
          } while (--R2_);
          R0_W = v5;
          v3 += 4;
          v4 = v11 - 2;
        } while ((int16)v4 >= 0);
        *(uint16 *)&stripe_image_upload_data[v3] = 255;
        stripe_image_upload = v3;
        flag_disable_layer3_scroll = 1;
        mirror_layer3_xpos = 0;
        mirror_layer3_ypos = 0;
      }
    }

    timer_wait_before_message_window_size_change += kDisplayMessage_DATA_05B10A[flag_message_window_size_change_direction];
    HIBYTE(v7) = timer_wait_before_message_window_size_change + 0x80;
    LOBYTE(v7) = 0x80 - timer_wait_before_message_window_size_change;
    uint8 v8 = 0;
    uint8 v9 = 80;
    do {
      if (v8 >= timer_wait_before_message_window_size_change)
        v7 = 255;
      *(uint16 *)&misc_hdmawindow_effect_table[v9 + 76] = v7;
      *(uint16 *)&misc_hdmawindow_effect_table[v8 + 156] = v7;
      v8 += 2;
      v9 -= 2;
    } while (v9);
    mirror_bg1_and2_window_mask_settings = 34;
    mirror_object_and_color_window_settings = misc_color_of_palace_switch_pressed1 ? 32 : 34;
    mirror_color_math_initial_settings = 34;
    mirror_hdmaenable = 0x80;
  }
}

void DisplayMessage_ExitToOverworldNoEvent() {  // 05b160
  misc_intro_level_flag = 0;
  sub_5B165(0);
}

void sub_5B165(uint8 a) {  // 05b165
  misc_exit_level_action = a;
  misc_game_mode = 11;
}

void DisplayMessage_DrawSwitchBlocks(uint8 k) {  // 05b2eb
  uint8 v1 = 16 * k;
  uint16 R0_W = 0;
  for (int8 i = 28; i >= 0; i -= 4) {
    OamEnt *oam = get_OamEnt(oam_buf, (uint8)i);
    *(uint16 *)&oam->charnum = kDisplayMessage_SwitchBlockTileAndProperties[v1 >> 1];
    *(uint16 *)&oam->xpos = *(uint16 *)&kDisplayMessage_SwitchBlockXAndYDisp[R0_W];
    v1 += 2;
    R0_W += 2;
  }
  *(uint16 *)oam_buf_ext = 0;
}

void DisplayMessage_RemoveSwitchBlocks() {  // 05b31b
  for (int8 i = 28; i >= 0; i -= 4)
    get_OamEnt(oam_buf, (uint8)i)->ypos = -16;
}

void GiveCoins_MultipleCoins(uint8 a) {  // 05b329
  io_sound_ch3 = 1;
  GiveCoins_MultipleCoins_NoCoinSound(a);
}

void GiveCoins_MultipleCoins_NoCoinSound(uint8 a) {  // 05b330
  uint8 r0 = a;
  counter_coin_handler += a;
  if (counter_green_star_block) {
    uint8 v1 = counter_green_star_block - r0;
    counter_green_star_block = (int8)v1 < 0 ? 0 : v1;
  }
}

void GiveCoins_OneCoin() {  // 05b34a
  ++counter_coin_handler;
  io_sound_ch3 = 1;
  if (counter_green_star_block)
    --counter_green_star_block;
}

uint8 UnusedOverworldEventPassedCheck(uint8 j) {  // 05b363
  return kBitTable_Bank05[j & 7] & ow_event_flags[j >> 3];
}

static const uint16 kLevelTileAnimationsAddrs[] = {
  0x600, 0x640, 0x680,
  0x740, 0xEA0, 0x800,
  0x500, 0x540, 0x580,
  0x5C0, 0x780, 0x7C0,
  0xDA0, 0x6C0, 0x700,
  0x4C0, 0x440, 0x480,
  0x400,     0,     0,
  0,     0,     0
};

void HandleLevelTileAnimations() {  // 05bb39
  uint8 v0 = 3 * (counter_local_frames & 7);
  uint16 R0_W = (uint8)(counter_local_frames & 0x18) >> 2;
  graphics_tile_anim_vramaddress3 = kLevelTileAnimationsAddrs[v0 + 0];
  graphics_tile_anim_vramaddress2 = kLevelTileAnimationsAddrs[v0 + 1];
  graphics_tile_anim_vramaddress1 = kLevelTileAnimationsAddrs[v0 + 2];
  uint8 v2 = 4;
  do {
    uint8 v4 = v2;
    uint8 v3 = v0;
    if (kLevelTileAnimations_DATA_05B96B[v0]) {
      if (kLevelTileAnimations_DATA_05B96B[v0] == 1) {
        if (*(&timer_blue_pswitch + kLevelTileAnimations_DATA_05B97D[v0]))
          v3 = v0 + 38;
      } else {
        v3 = kLevelTileAnimations_DATA_05B98B[misc_level_tileset_setting] + v0;
      }
    }
    *(uint16 *)((int8 *)&graphics_tile_anim_source_address1 + v2) = kLevelTileAnimations_FrameData[(uint16)(R0_W | (8 * v3)) >> 1];
    ++v0;
    v2 -= 2;
  } while ((int8)v2 >= 0);
}

void HandleScrollSpriteAndLayer3Scrolling() {  // 05bc00
  ProcessScrollSprites_Layer1();
  ProcessScrollSprites_Layer2();
  ScrollSecondInteractiveLayer();
  PointU16 *pt = get_PointU16(misc_layer1_pos, 0);
  misc_layer1_xdisp += LOBYTE(pt->x) - mirror_current_layer1_xpos;
  misc_layer1_ydisp += LOBYTE(pt->y) - mirror_current_layer1_ypos;
  uint8 v1 = LOBYTE(pt[1].x) - mirror_current_layer2_xpos;
  if (l1_l2_scroll_spr_spriteid[1] == 1)
    v1 = l1_l2_scroll_spr_spriteid[1] - 1;
  misc_layer2_xdisp = v1;
  misc_layer2_ydisp = LOBYTE(pt[1].y) - mirror_current_layer2_ypos;
  if (!flag_disable_layer3_scroll)
    ScrollLayer3();
}

void ProcessScrollSprites_Return() {  // 05bc49
  ;
}

void ScrollSecondInteractiveLayer() {  // 05bc4a
  uint16 y;
  if (flag_layer3_tide_level) {
    misc_second_level_layer_xpos = mirror_layer3_xpos - get_PointU16(misc_layer1_pos, 0)->x;
    y = mirror_layer3_ypos;
  } else {
    PointU16 *pt = get_PointU16(misc_layer1_pos, 0);
    misc_second_level_layer_xpos = pt[1].x - pt->x;
    y = pt[1].y;
  }
  misc_second_level_layer_ypos = y - get_PointU16(misc_layer1_pos, 0)->y;
}

void ProcessScrollSprites_Layer1() {  // 05bc76
  scroll_spr_layer_index = 0;
  if (!flag_sprites_locked) {
    if (l1_l2_scroll_spr_spriteid[0])
      kProcessScrollSprites_Ptrs05BC87[l1_l2_scroll_spr_spriteid[0]]();
  }
}

void ProcessScrollSprites_Layer2() {  // 05bca5
  scroll_spr_layer_index = 4;
  if (l1_l2_scroll_spr_spriteid[1]) {
    if (!flag_sprites_locked)
      kProcessScrollSprites_Ptrs05BCB8[l1_l2_scroll_spr_spriteid[1]]();
  }
}

void InitializeScrollSprites() {  // 05bcd6
  scroll_spr_layer_index = 0;
  InitializeScrollSprites_05BCE9();
  scroll_spr_layer_index = 4;
  InitializeScrollSprites_05BD0E();
}

void InitializeScrollSprites_05BCE9() {  // 05bce9
  kInitializeScrollSprites_Ptrs05BCF0[l1_l2_scroll_spr_spriteid[0]]();
}

void InitializeScrollSprites_05BD0E() {  // 05bd0e
  if (l1_l2_scroll_spr_spriteid[1])
    kUnk_5bd17[l1_l2_scroll_spr_spriteid[1]]();
}

void InitializeScrollSprites_Return05BD35() {  // 05bd35
  ;
}

void Spr0E7_SpecialAutoScroll() {  // 05bd36
  flag_layer1_horiz_scroll_level_setting = 0;
  *(uint16 *)l1_l2_scroll_spr_spriteid =
      *(uint16 *)&kSpr0E7_SpecialAutoScroll_L1AndL2ScrollID[(uint8)(2 * l1_l2_scroll_spr_scroll_type_index[0])];
  *(uint16 *)l1_l2_scroll_spr_scroll_type_index =
      *(uint16 *)&kSpr0E7_SpecialAutoScroll_L1AndL2ScrollTypeIndex[(uint8)(2 * l1_l2_scroll_spr_scroll_type_index[0])];
  Spr0E7_SpecialAutoScroll_Layer2();
}

void Spr0E7_SpecialAutoScroll_Layer2() {  // 05bd4c
  uint8 v0 = scroll_spr_layer_index;
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_speed, scroll_spr_layer_index);
  pt->x = 0;
  pt->y = 0;
  PointU16 *v2 = get_PointU16(l1_l2_scroll_spr_sub_pos, v0);
  v2->x = 0;
  v2->y = 0;
  uint8 v3 = v0 >> 2;
  uint8 v4 = l1_l2_scroll_spr_scroll_type_index[0];
  if (scroll_spr_layer_index)
    v4 = l1_l2_scroll_spr_scroll_type_index[1];
  l1_l2_scroll_spr_current_state[v3] = kSpr0E7_SpecialAutoScroll_DATA_05CA61[v4];
  l1_l2_scroll_spr_timer[v3] = kSpr0E7_SpecialAutoScroll_DATA_05CA68[v4];
}

void MostlyUnusedScrollSpriteRoutine() {  // 05bd7b
  int v0 = (uint8)(2 * l1_l2_scroll_spr_scroll_type_index[0]) >> 1;
  *(uint16 *)l1_l2_scroll_spr_spriteid = kMostlyUnusedScrollSpriteRoutine_UNK_05C9E5[v0];
  *(uint16 *)l1_l2_scroll_spr_scroll_type_index = kMostlyUnusedScrollSpriteRoutine_UNK_05C9E5[v0 + 1];
  uint8 v1 = l1_l2_scroll_spr_scroll_type_index[0];
  if (scroll_spr_layer_index)
    v1 = l1_l2_scroll_spr_scroll_type_index[1];
  *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] = kMostlyUnusedScrollSpriteRoutine_UNK_05C9E5[(v1 >> 1) + 2];
  uint8 v2 = kSharedScrollSpriteTables_UNK_05CBC7[v1];
  if (v2)
    v2 = -v2;
  uint8 v3 = scroll_spr_layer_index;
  uint16 v4 = (uint8)(LOBYTE(get_PointU16(misc_layer1_pos, scroll_spr_layer_index)->y) + v2);
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index);
  pt->x = v4;
  pt->y = 0;
  MostlyUnusedScrollSpriteRoutine_05BDC9(v3);
}

void MostlyUnusedScrollSpriteRoutine_05BDC9(uint8 k) {  // 05bdc9
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_speed, k);
  pt->x = 0;
  pt->y = 0;
  MostlyUnusedScrollSpriteRoutine_05BDCF(k);
}

void MostlyUnusedScrollSpriteRoutine_05BDCF(uint8 k) {  // 05bdcf
  l1_l2_scroll_spr_timer[k >> 2] = -1;
}

void Spr0EB_UnusedSprite() {  // 05bddd
  int v0 = (uint8)(2 * l1_l2_scroll_spr_scroll_type_index[0]) >> 1;
  *(uint16 *)l1_l2_scroll_spr_spriteid = kSpr0EB_UnusedSprite_DATA_05CA08[v0];
  *(uint16 *)l1_l2_scroll_spr_scroll_type_index = kSpr0EB_UnusedSprite_DATA_05CA0C[v0];
  Spr0EB_UnusedSprite_05BDF0();
}

void Spr0EB_UnusedSprite_05BDF0() {  // 05bdf0
  uint8 v0 = l1_l2_scroll_spr_scroll_type_index[0];
  if (scroll_spr_layer_index)
    v0 = l1_l2_scroll_spr_scroll_type_index[1];
  uint16 v1 = kSpr0EB_UnusedSprite_DATA_05CA10[v0 >> 1];
  *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] = v1;
  uint16 R0_W = kSpr0EB_UnusedSprite_DATA_05CA10[((uint8)(2 * v0) >> 1) + 1];
  int8 v2 = v1;
  uint8 v3 = scroll_spr_layer_index;
  uint16 v4 = R0_W;
  if (v2 != 1)
    v4 = -R0_W;
  uint16 v5 = get_PointU16(misc_layer1_pos, scroll_spr_layer_index)->y + v4;
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index);
  pt->x = v5;
  PointU16 *v7 = get_PointU16(l1_l2_scroll_spr_speed, v3);
  v7->x = 0;
  v7->y = 0;
  pt->y = 0;
}

void Spr0F1_UnusedSprite() {  // 05be3a
  int v0 = (uint8)(2 * l1_l2_scroll_spr_scroll_type_index[0]) >> 1;
  *(uint16 *)l1_l2_scroll_spr_spriteid = kSpr0F1_UnusedSprite_DATA_05CA16[v0];
  *(uint16 *)l1_l2_scroll_spr_scroll_type_index = kSpr0F1_UnusedSprite_DATA_05CA1E[v0];
  Spr0F1_UnusedSprite_05BE4D();
}

void Spr0F1_UnusedSprite_05BE4D() {  // 05be4d
  uint8 v0 = l1_l2_scroll_spr_scroll_type_index[0];
  if (scroll_spr_layer_index)
    v0 = l1_l2_scroll_spr_scroll_type_index[1];
  uint16 v1 = kSpr0F1_UnusedSprite_DATA_05CA26[v0 >> 1];
  *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] = v1;
  int8 v2 = v1;
  uint8 v3 = scroll_spr_layer_index;
  int16 v4 = 0xf17;
  if (v2 != 1)
    v4 = 0xf0e9;
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index);
  pt->y = v4;
  PointU16 *v6 = get_PointU16(l1_l2_scroll_spr_speed, v3);
  v6->x = 0;
  v6->y = 0;
  pt->x = 0;
}

void GameMode12_PrepareLevel_InitializeLayer3RAM() {  // 05be8a
  *(uint16 *)&flag_layer3_vert_scroll_direction = kSpr0F1_UnusedSprite_DATA_05CA26[0];
  misc_layer3_xspeed = 0;
  misc_layer3_yspeed = 0;
  misc_layer3_tide_sub_ypos = 0;
  mirror_layer3_ypos = mirror_current_layer1_ypos;
}

void Spr0EF_Layer2ScrollSOrL() {  // 05bea6
  flag_layer1_horiz_scroll_level_setting = 0;
  int v0 = (uint8)(2 * l1_l2_scroll_spr_scroll_type_index[0]) >> 1;
  *(uint16 *)l1_l2_scroll_spr_spriteid = kSpr0EF_Layer2ScrollSOrL_DATA_05CA3E[v0];
  *(uint16 *)l1_l2_scroll_spr_scroll_type_index = kSpr0EF_Layer2ScrollSOrL_DATA_05CA42[v0];
  mirror_current_layer1_xpos = 0;
  PointU16 *pt = get_PointU16(misc_layer1_pos, 0);
  pt->x = 0;
  mirror_current_layer2_xpos = 0;
  pt[1].x = 0;
  Spr0EF_Layer2ScrollSOrL_05BEC6();
}

void Spr0EF_Layer2ScrollSOrL_05BEC6() {  // 05bec6
  uint8 v0 = l1_l2_scroll_spr_scroll_type_index[0];
  if (scroll_spr_layer_index)
    v0 = l1_l2_scroll_spr_scroll_type_index[1];
  int16 v1 = *(uint16 *)((int8 *)&kSpr0EF_Layer2ScrollSOrL_DATA_05CA46 + v0);
  *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] = v1;
  int8 v2 = v1;
  uint8 v3 = kSharedScrollSpriteTables_DATA_05CBED[(uint8)(2 * v0)];
  if (v2 != 1)
    v3 = -v3;
  uint8 v4 = scroll_spr_layer_index;
  uint16 v5 = (uint8)(LOBYTE(get_PointU16(misc_layer1_pos, scroll_spr_layer_index)->x) + v3);
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index);
  pt->y = v5;
  pt->x = 0;
  MostlyUnusedScrollSpriteRoutine_05BDC9(v4);
}

void Spr0EA_Layer2Scroll() {  // 05bf0a
  flag_layer2_vert_scroll_level_setting = 0;
  int v0 = (uint8)(2 * l1_l2_scroll_spr_scroll_type_index[0]) >> 1;
  *(uint16 *)l1_l2_scroll_spr_spriteid = kSpr0EA_Layer2Scroll_DATA_05CA48[v0];
  *(uint16 *)l1_l2_scroll_spr_scroll_type_index = kSpr0EA_Layer2Scroll_DATA_05CA52[v0];
  Spr0EA_Layer2Scroll_05BF20();
}

void Spr0EA_Layer2Scroll_05BF20() {  // 05bf20
  uint8 v0 = l1_l2_scroll_spr_scroll_type_index[0];
  if (scroll_spr_layer_index)
    v0 = l1_l2_scroll_spr_scroll_type_index[1];
  uint16 v1 = WORD(*((uint8 *)kSpr0EA_Layer2Scroll_DirectionToStartMoving + v0));
  *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] = v1;
  int8 v2 = v1;
  uint8 v3 = kSharedScrollSpriteTables_DATA_05CBF5[(uint8)(2 * v0)];
  if (v2 != 1)
    v3 = -v3;
  uint8 v4 = scroll_spr_layer_index;
  uint16 v5 = (uint8)(LOBYTE(get_PointU16(misc_layer1_pos, scroll_spr_layer_index)->y) + v3);
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index);
  pt->x = v5;
  pt->y = 0;
  PointU16 *v7 = get_PointU16(l1_l2_scroll_spr_speed, v4);
  v7->y = 0;
  v7->y = 0;
  MostlyUnusedScrollSpriteRoutine_05BDCF(v4);
}

void Spr0E9_Layer2Smash() {  // 05bf6a
  int v1 = l1_l2_scroll_spr_scroll_type_index[0];
  l1_l2_scroll_spr_scroll_type_index[0] = kSpr0E9_Layer2Smash_DATA_05C94F[l1_l2_scroll_spr_scroll_type_index[0]];
  l1_l2_scroll_spr_scroll_type_index[1] = kSpr0E9_Layer2Smash_DATA_05C952[v1];
  Spr0EC_UnusedSprite_05BFD2(0x200);
  Layer2SpecialScrolling02_Layer2Smash_05C95B(l1_l2_scroll_spr_scroll_type_index[0] + 10, 1);
  mirror_current_layer2_ypos = get_PointU16(misc_layer1_pos, 0)[1].y;
}

void Spr0ED_Layer2Falls() {  // 05bf97
  flag_layer1_horiz_scroll_level_setting = 0;
  mirror_current_layer1_xpos = 0;
  PointU16 *pt = get_PointU16(misc_layer1_pos, 0);
  pt->x = 0;
  mirror_current_layer2_xpos = 0;
  pt[1].x = 0;
  *(uint16 *)l1_l2_scroll_spr_spriteid = 0x600;
  get_PointU16(l1_l2_scroll_spr_speed, 0)[1].y = 0;
  get_PointU16(l1_l2_scroll_spr_sub_pos, 0)[1].y = 0;
  l1_l2_scroll_spr_scroll_type_index[1] = 96;
}

void Spr0EC_UnusedSprite() {  // 05bfba
  flag_layer1_horiz_scroll_level_setting = 0;
  mirror_current_layer2_xpos = 0;
  PointU16 *pt = get_PointU16(misc_layer1_pos, 0);
  pt[1].x = 0;
  mirror_current_layer2_ypos = 960;
  pt[1].y = 960;
  *(uint16 *)l1_l2_scroll_spr_scroll_type_index = 0;
  Spr0EC_UnusedSprite_05BFD2(5);
}

void Spr0EC_UnusedSprite_05BFD2(uint16 a) {  // 05bfd2
  *(uint16 *)l1_l2_scroll_spr_timer = 0;
  Spr0EC_UnusedSprite_05BFD5(a);
}

void Spr0EC_UnusedSprite_05BFD5(uint16 a) {  // 05bfd5
  *(uint16 *)l1_l2_scroll_spr_current_state = 0;
  *(uint16 *)l1_l2_scroll_spr_spriteid = a;
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_speed, 0);
  pt->x = 0;
  pt->y = 0;
  PointU16 *v2 = get_PointU16(l1_l2_scroll_spr_sub_pos, 0);
  v2->x = 0;
  v2->y = 0;
  pt[1].x = 0;
  pt[1].y = 0;
  v2[1].x = 0;
  v2[1].y = 0;
}

void Spr0EC_UnusedSprite_Return05BFF5() {  // 05bff5
  ;
}

void Spr0F2_Layer2OnOffControlled() {  // 05bff6
  Spr0EC_UnusedSprite_05BFD2(0xB00);
}

void Spr0F3_RegularAutoScroll() {  // 05c005
  flag_layer1_horiz_scroll_level_setting = 0;
  *(uint16 *)l1_l2_scroll_spr_scroll_type_index =
      kSpr0F3_RegularAutoScroll_DATA_05BFFD[(uint8)(2 * l1_l2_scroll_spr_scroll_type_index[0]) >> 1];
  Spr0EC_UnusedSprite_05BFD2(0xC);
}

void Spr0F4_FastBGScroll() {  // 05c01a
  Spr0EC_UnusedSprite_05BFD2(0xD00);
  Spr0F4_FastBGScroll_05C022();
}

void Spr0F4_FastBGScroll_05C022() {  // 05c022
  flag_layer2_horiz_scroll_level_setting = 0;
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_speed, 0);
  pt[1].x = 0;
  pt[1].y = 0;
  PointU16 *v1 = get_PointU16(l1_l2_scroll_spr_sub_pos, 0);
  v1[1].x = 0;
  v1[1].y = 0;
}

void Spr0F5_Layer2ScrollWhenTouched() {  // 05c036
  l1_l2_scroll_spr_timer[0] = kSpr0F5_Layer2ScrollWhenTouched_DATA_05C808[l1_l2_scroll_spr_scroll_type_index[0]];
  l1_l2_scroll_spr_timer[1] = kSpr0F5_Layer2ScrollWhenTouched_DATA_05C80B[l1_l2_scroll_spr_scroll_type_index[0]];
  Spr0EC_UnusedSprite_05BFD5(0xE00);
}

void Layer1SpecialScrolling00_VariableScroll() {  // 05c04d
  uint16 rw;
  uint16 r12;
  uint16 r10;
  uint16 r8;
  uint16 R0_W, R2_W;

  while (1) {
    if (!l1_l2_scroll_spr_timer[scroll_spr_layer_index >> 2]) {
      LOBYTE(get_PointU16(l1_l2_scroll_spr_speed, scroll_spr_layer_index)->x) = 0;
      return;
    }
    uint8 v0 = *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2];
    uint16 R4_W = kLayer1SpecialScrolling01_VariableScroll_DATA_05CA6F[v0 - 1];
    uint16 r6 = kLayer1SpecialScrolling01_VariableScroll_DATA_05CABF[v0 - 1];
    PointU16 *pt = get_PointU16(misc_layer1_pos, scroll_spr_layer_index);
    R0_W = pt->x;
    R2_W = pt->y;
    uint8 v2 = 2;
    if (kLayer1SpecialScrolling01_VariableScroll_DATA_05CA6F[v0] == R4_W) {
      R4_W = 0;
      r8 = 2;
    } else {
      int16 v3 = 16 * kLayer1SpecialScrolling01_VariableScroll_DATA_05CA6F[v0] - R0_W;
      R0_W = v3;
      if (v3 < 0) {
        v2 = 0;
        v3 = -v3;
      }
      R4_W = v3;
      r8 = v2;
    }
    uint8 v4 = 0;
    if (kLayer1SpecialScrolling01_VariableScroll_DATA_05CABF[v0] == r6) {
      r6 = 0;
    } else {
      int16 v5 = 16 * kLayer1SpecialScrolling01_VariableScroll_DATA_05CABF[v0] - R2_W;
      R2_W = v5;
      if (v5 < 0) {
        v4 = 2;
        v5 = -v5;
      }
      r6 = v5;
    }
    if (!(misc_level_layout_flags & 1))
      v4 = r8;
    camera_layer1_scrolling_direction = v4;
    r8 = -1;
    r10 = R4_W;
    r12 = r6;
    if (r6 >= R4_W) {
      r10 = r6;
      r12 = R4_W;
      r8 = 1;
    }
    rw = SnesDivide(r10, kLayer1SpecialScrolling01_VariableScroll_DATA_05CB0F[v0]);
    if (rw)
      break;
    uint16 v7 = scroll_spr_layer_index >> 2;
    ++*(uint16 *)&l1_l2_scroll_spr_current_state[(uint8)v7];
    --l1_l2_scroll_spr_timer[(uint8)v7];
  }
  r10 = rw;
  r12 *= 16;
  uint8 v8 = 16;
  uint16 v9 = 0;
  uint16 r14 = 0;
  do {
    v9 = 2 * v9 + __CFSHL__uint16(r12);
    r12 *= 2;
    bool v10 = v9 >= r10;
    if (v9 >= r10)
      v9 -= r10;
    r14 = 2 * r14 + v10;
  } while (--v8);
  r10 = 16 * kLayer1SpecialScrolling01_VariableScroll_DATA_05CB0F[(uint8) *
                                                                    (uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2]];
  uint8 v11 = 2;
  do {
    uint16 v12;
    if ((r8 & 0x8000) != 0)
      v12 = r14;
    else
      v12 = r10;
    if ((int16)(v11 ? R2_W : R0_W) < 0)
      v12 = -v12;
    uint8 v16 = v11;
    uint8 v13 = scroll_spr_layer_index + v11;
    uint8 v14 = 0;
    PointU16 *v15 = get_PointU16(l1_l2_scroll_spr_speed, v13);
    if (v12 != v15->x) {
      if ((int16)(v12 - v15->x) < 0)
        v14 = 2;
      v15->x += *(uint16 *)&kLayer1SpecialScrolling01_VariableScroll_DATA_05CB5F[v14];
    }
    UpdateLayerPositionWithScrollSprite(v13);
    r8 = -r8;
    v11 = v16 - 2;
  } while ((int8)v11 >= 0);
}

void Layer2SpecialScrolling01_VariableScroll() {  // 05c198
  Layer1SpecialScrolling00_VariableScroll();
  PointU16 *pt = get_PointU16(misc_layer1_pos, 0);
  pt->x = pt[1].x;
  mirror_current_layer2_ypos += shaking_layer1_disp_y;
}

void UnusedScrollSpriteRoutine() {  // 05c1ae
  uint8 v0 = scroll_spr_layer_index >> 2;
  if ((l1_l2_scroll_spr_timer[scroll_spr_layer_index >> 2] & 0x80) != 0) {
    uint16 x = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index)->x;
    PointU16 *pt = get_PointU16(misc_layer1_pos, scroll_spr_layer_index);
    uint16 R2_W, R4_W;
    if (pt->y < x) {
      R2_W = pt->y;
      R4_W = x;
    } else {
      R4_W = pt->y;
      R2_W = x;
    }
    if (R2_W >= R4_W) {
      l1_l2_scroll_spr_timer[scroll_spr_layer_index >> 2] = 48;
      uint8 v4 = scroll_spr_layer_index;
      get_PointU16(l1_l2_scroll_spr_speed, scroll_spr_layer_index)->y = 0;
      get_PointU16(l1_l2_scroll_spr_sub_pos, v4)->y = 0;
      uint8 v5 = l1_l2_scroll_spr_scroll_type_index[0];
      if (scroll_spr_layer_index)
        v5 = l1_l2_scroll_spr_scroll_type_index[1];
      uint16 R0_W = kSharedScrollSpriteTables_UNK_05CBC7[v5];
      uint8 v6 = v4 >> 2;
      uint16 v7 = *(uint16 *)&l1_l2_scroll_spr_current_state[v6] ^ 1;
      *(uint16 *)&l1_l2_scroll_spr_current_state[v6] = v7;
      if (!(uint8)v7)
        R0_W = -R0_W;
      PointU16 *v8 = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index);
      v8->x += R0_W;
    }
    uint8 v9 = *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2];
    uint16 v10 = kSharedScrollSpriteTables_UNK_05CBC7[v9 + 1];
    if (v9 != 1)
      v10 = -v10;
    uint8 v11 = 0;
    PointU16 *v12 = get_PointU16(l1_l2_scroll_spr_speed, scroll_spr_layer_index);
    if (v10 != v12->y) {
      if ((int16)(v10 - v12->y) < 0)
        v11 = 2;
      v12->y += kUnusedScrollSpriteRoutine_DATA_05CB7B[v11 >> 1];
    }
    Layer2SpecialScrolling04_Unused_05C328(scroll_spr_layer_index + 2);
  } else if (--l1_l2_scroll_spr_timer[v0] >= 0x20) {
    PointU16 *v1 = get_PointU16(misc_layer1_pos, scroll_spr_layer_index);
    v1->y ^= 1;
  }
}

void Layer1SpecialScrolling04_Unused() {  // 05c283
  uint16 x = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index)->x;
  uint16 v1 = x - get_PointU16(misc_layer1_pos, scroll_spr_layer_index)->y;
  if (v1 < 0)
    v1 = -v1;
  uint16 R2_W = v1;
  uint8 v2 = l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2];
  if (!SnesDivide(v1, kLayer2SpecialScrolling04_Unused_DATA_05CBE3[v2 >> 1])) {
    v2 = *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2];
    uint16 v3 = 512;
    if (v2 == 1)
      v3 = -512;
    PointU16 *pt = get_PointU16(misc_layer1_pos, scroll_spr_layer_index);
    pt->y += v3;
  }
  uint8 v5 = l1_l2_scroll_spr_scroll_type_index[0];
  if (scroll_spr_layer_index)
    v5 = l1_l2_scroll_spr_scroll_type_index[1];
  uint16 v6 = 16 * kLayer2SpecialScrolling04_Unused_DATA_05CBE3[v5];
  if (v2 != 1)
    v6 = -16 * kLayer2SpecialScrolling04_Unused_DATA_05CBE3[v5];
  uint8 v7 = 0;
  PointU16 *v8 = get_PointU16(l1_l2_scroll_spr_speed, scroll_spr_layer_index);
  if (v6 != v8->y) {
    if ((int16)(v6 - v8->y) < 0)
      v7 = 2;
    v8->y += kLayer2SpecialScrolling04_Unused_DATA_05CB9B[v7 >> 1];
  }
  Layer2SpecialScrolling04_Unused_05C328(scroll_spr_layer_index + 2);
}

void Layer2SpecialScrolling04_Unused_05C328(uint8 k) {  // 05c328
  UpdateLayerPositionWithScrollSprite(k);
}

void Layer1SpecialScrolling0A_Unused() {  // 05c32e
  uint16 y = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index)->y;
  uint16 v1 = y - get_PointU16(misc_layer1_pos, scroll_spr_layer_index)->x;
  if (v1 < 0)
    v1 = -v1;
  uint16 R2_W = v1;
  uint8 v2 = l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] >> 1;
  if (!SnesDivide(v1, kLayer2SpecialScrolling0A_Unused_DATA_05CBE5[v2])) {
    uint8 v3 = scroll_spr_layer_index;
    uint16 v4 = 0x600;
    if ((uint8) * (uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] == 1)
      v4 = 0xfa00;
    PointU16 *pt = get_PointU16(misc_layer1_pos, scroll_spr_layer_index);
    pt->x += v4;
    *(uint16 *)((int8 *)&camera_layer1_row_column_to_update_left_up + v3) = -8;
    *(uint16 *)((int8 *)&camera_layer1_row_column_to_update_right_down + v3) = 23;
    *(uint16 *)((int8 *)&player_xpos + 1) = 0;
  }
  uint8 v12 = l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2];
  uint8 v6 = 2;
  uint8 v7 = 0;
  if (v12 != 1) {
    v6 = 0;
    v7 = 1;
  }
  *(&camera_layer1_scrolling_direction + v7) = v6;
  uint8 v8 = l1_l2_scroll_spr_scroll_type_index[0];
  if (scroll_spr_layer_index)
    v8 = l1_l2_scroll_spr_scroll_type_index[1];
  uint16 v9 = 16 * kLayer2SpecialScrolling0A_Unused_DATA_05CBE5[v8];
  if (v12 != 1)
    v9 = -16 * kLayer2SpecialScrolling0A_Unused_DATA_05CBE5[v8];
  uint8 v10 = 0;
  PointU16 *v11 = get_PointU16(l1_l2_scroll_spr_speed, scroll_spr_layer_index);
  if (v9 != v11->x) {
    if ((int16)(v9 - v11->x) < 0)
      v10 = 2;
    v11->x += kLayer2SpecialScrolling0A_Unused_DATA_05CBA3[v10 >> 1];
  }
  UpdateLayerPositionWithScrollSprite(scroll_spr_layer_index);
}

void ScrollLayer3() {  // 05c40c
  if (flag_layer3_tide_level) {
    if (flag_layer3_tide_level == 1 && !flag_sprites_locked) {
      if ((counter_local_frames & 3) != 0) {
LABEL_26:
        if ((uint8)mirror_layer3_ypos == kScrollLayer3_TideMaxYPos[flag_layer3_vert_scroll_direction])
          flag_layer3_vert_scroll_direction ^= 1;
        uint16 t = misc_layer3_tide_sub_ypos + (uint8)(16 * misc_layer3_yspeed);
        LOBYTE(misc_layer3_tide_sub_ypos) = t;
        LOBYTE(mirror_layer3_ypos) = mirror_layer3_ypos + ((int8)misc_layer3_yspeed >> 4) + (t >> 8);
        goto LABEL_31;
      }
      if ((uint8)misc_layer3_yspeed ||
          (--timer_wait_before_layer3_tide_moves_vertically, !timer_wait_before_layer3_tide_moves_vertically)) {
        if ((uint8)misc_layer3_yspeed != kScrollLayer3_TideMaxYSpeed[flag_layer3_vert_scroll_direction])
          LOBYTE(misc_layer3_yspeed) = kScrollLayer3_TideYAcceleration[flag_layer3_vert_scroll_direction] + misc_layer3_yspeed;
        timer_wait_before_layer3_tide_moves_vertically = 75;
        goto LABEL_26;
      }
    }
LABEL_31:
    LOBYTE(mirror_layer3_xpos) = misc_layer1_xdisp + mirror_layer3_xpos + 1;
    HIBYTE(mirror_layer3_xpos) = 1;
    return;
  }
  if (misc_level_tileset_setting == 1 || misc_level_tileset_setting == 3) {
    mirror_layer3_xpos = mirror_current_layer1_xpos >> 1;
  } else {
    if (!flag_sprites_locked) {
      uint16 v0 = 16 * kScrollLayer3_DATA_05CBEB[0];
      if (flag_layer3_vert_scroll_direction != 1)
        v0 = -16 * kScrollLayer3_DATA_05CBEB[0];
      uint8 v1 = 0;
      if (v0 != misc_layer3_xspeed) {
        if ((int16)(v0 - misc_layer3_xspeed) < 0)
          v1 = 2;
        misc_layer3_xspeed += kScrollLayer3_DATA_05CBBB[v1 >> 1];
      }
      misc_layer3_tide_sub_ypos = misc_layer3_xspeed + (uint8)misc_layer3_tide_sub_ypos;
      uint16 v2 = misc_layer3_tide_sub_ypos & 0xFF00;
      if ((misc_layer3_tide_sub_ypos & 0x8000) != 0)
        v2 |= 0xFF;
      mirror_layer3_xpos += swap16(v2);
      uint16 v5 = misc_layer1_xdisp;
      if (misc_layer1_xdisp >= 0x80)
        v5 = misc_layer1_xdisp | 0xFF00;
      mirror_layer3_xpos += v5;
    }
    mirror_layer3_ypos = mirror_current_layer1_ypos;
  }
}

void UpdateLayerPositionWithScrollSprite(uint8 k) {  // 05c4f9
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_sub_pos, k);
  uint16 v2 = get_PointU16(l1_l2_scroll_spr_speed, k)->x + LOBYTE(pt->x);
  pt->x = v2;
  PointU16 *v6 = get_PointU16(misc_layer1_pos, k);
  v6->x += (int8)(v2 >> 8);
  //R8_W = -R8_W;
}

void Layer1SpecialScrolling08_Layer2ScrollSOrL() {  // 05c51f
  uint16 y = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index)->y;
  PointU16 *pt = get_PointU16(misc_layer1_pos, scroll_spr_layer_index);
  uint16 R2_W, R4_W;
  if (pt->x < y) {
    R2_W = pt->x;
    R4_W = y;
  } else {
    R4_W = pt->x;
    R2_W = y;
  }
  if (R2_W >= R4_W) {
    uint8 v2 = l1_l2_scroll_spr_scroll_type_index[0];
    if (*(uint16 *)&scroll_spr_layer_index)
      v2 = l1_l2_scroll_spr_scroll_type_index[1];
    uint16 R0_W = kSharedScrollSpriteTables_DATA_05CBED[(uint8)(2 * v2) + 1];
    uint16 v3 = *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] ^ 1;
    *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] = v3;
    if (!(uint8)v3)
      R0_W = -R0_W;
    PointU16 *v4 = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index);
    v4->y += R0_W;
  }
  uint8 v5 = *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2];
  uint16 v6 = kSharedScrollSpriteTables_DATA_05CBF1[v5];
  if (v5 != 1)
    v6 = -v6;
  uint8 v7 = scroll_spr_layer_index;
  PointU16 *v9 = get_PointU16(l1_l2_scroll_spr_speed, scroll_spr_layer_index);
  if (v6 != v9->x) {
    uint8 v8 = (int16)(v6 - v9->x) < 0 ? 2 : 0;
    v9->x += kSharedScrollSpriteTables_DATA_05CBC3[v8 >> 1];
  }
  Layer2SpecialScrolling04_Unused_05C328(v7);
}

void Layer2SpecialScrolling03_Layer2Scroll() {  // 05c5bb
  uint16 x = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index)->x;
  PointU16 *pt = get_PointU16(misc_layer1_pos, scroll_spr_layer_index);
  uint16 R2_W, R4_W;
  if (pt->y < x) {
    R2_W = pt->y;
    R4_W = x;
  } else {
    R4_W = pt->y;
    R2_W = x;
  }
  if (R2_W >= R4_W) {
    uint8 v2 = l1_l2_scroll_spr_scroll_type_index[0];
    if (*(uint16 *)&scroll_spr_layer_index)
      v2 = l1_l2_scroll_spr_scroll_type_index[1];
    uint16 R0_W = kSharedScrollSpriteTables_DATA_05CBF5[(uint8)(2 * v2) + 1];
    uint16 v3 = *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] ^ 1;
    *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2] = v3;
    if (!(uint8)v3)
      R0_W = -R0_W;
    PointU16 *v4 = get_PointU16(l1_l2_scroll_spr_sub_pos, scroll_spr_layer_index);
    v4->x += R0_W;
  }
  uint8 v5 = *(uint16 *)&l1_l2_scroll_spr_current_state[scroll_spr_layer_index >> 2];
  uint16 v6 = kSharedScrollSpriteTables_DATA_05CBF1[v5];
  if (v5 != 1)
    v6 = -v6;
  uint8 v7 = scroll_spr_layer_index;
  uint8 v8 = 0;
  PointU16 *v9 = get_PointU16(l1_l2_scroll_spr_speed, scroll_spr_layer_index);
  if (v6 != v9->y) {
    if ((int16)(v6 - v9->y) < 0)
      v8 = 2;
    v9->y += kSharedScrollSpriteTables_DATA_05CBC3[v8 >> 1];
  }
  Layer2SpecialScrolling04_Unused_05C328(v7 + 2);
}

void Layer2SpecialScrolling06_Unused() {  // 05c659
  uint8 v0 = l1_l2_scroll_spr_scroll_type_index[1];
  if (l1_l2_scroll_spr_scroll_type_index[1]) {
    --l1_l2_scroll_spr_scroll_type_index[1];
    if (v0 < 0x20 && (counter_local_frames & 1) == 0) {
      PointU16 *pt = get_PointU16(misc_layer1_pos, 0);
      LOBYTE(pt->y) ^= 1;
    }
  } else {
    camera_layer2_scrolling_direction = 0;
    PointU16 *v2 = get_PointU16(l1_l2_scroll_spr_speed, 0);
    PointU16 *v3 = v2;
    if (v2[1].y != 0xFFC0)
      --v2[1].y;
    PointU16 *v4 = get_PointU16(misc_layer1_pos, 0);
    if (sign16(v4[1].y - 49))
      v3[1].y = 0;
    if (v4[1].y == 49)
      l1_l2_scroll_spr_scroll_type_index[1] = 32;
    UpdateLayerPositionWithScrollSprite(6);
  }
}

void Layer1SpecialScrolling05_Unused() {  // 05c69e
  uint16 v8;

  camera_layer1_scrolling_direction = 2;
  camera_layer2_scrolling_direction = 0;
  if (l1_l2_scroll_spr_scroll_type_index[0]) {
    RtlPpuWrite(TM, 0x16);
    PointU16 *pt = get_PointU16(l1_l2_scroll_spr_speed, 0);
    uint16 y = pt[1].y;
    if (y != 0xFF80)
      --y;
    pt[1].y = y;
    pt->y = y;
    if (!get_PointU16(misc_layer1_pos, 0)[1].y) {
      pt[1].y = 0;
      pt->y = 0;
    }
  } else {
    PointU16 *v0 = get_PointU16(l1_l2_scroll_spr_speed, 0);
    PointU16 *v1 = v0;
    uint16 x = v0->x;
    if (v0->x != 128)
      ++x;
    v0->x = x;
    if ((uint8)(camera_last_screen_horiz - 1) == HIBYTE(get_PointU16(misc_layer1_pos, 0)->x)) {
      ++*(uint16 *)l1_l2_scroll_spr_scroll_type_index;
      v1->x = 0;
      unusedram_unknown_scroll_function_flag = -784;
    }
  }
  for (int i = 6; i >= 0; i -= 2)
    UpdateLayerPositionWithScrollSprite(i);
  PointU16 *v7 = get_PointU16(misc_layer1_pos, 0);
  HIBYTE(v8) = HIBYTE(v7->x) - camera_last_screen_horiz + 2;
  LOBYTE(v8) = v7->x;
  uint8 v9 = -126;
  if (sign16(v8)) {
    v8 = 0;
    v9 = 2;
  }
  v7[1].x = v8;
  mirror_current_layer2_xpos = v8;
  misc_level_layout_flags = v9;
}

void Layer1SpecialScrolling0B_Layer2OnOffControlled() {  // 05c727
  uint8 v0 = flag_on_off_switch;
  if (flag_on_off_switch)
    v0 = 2;
  if (v0 == l1_l2_scroll_spr_current_state[1]) {
    l1_l2_scroll_spr_timer[1] = 16;
    if (get_PointU16(misc_layer1_pos, 0)[1].y == kLayer2SpecialScrolling0B_Layer2OnOffControlled_DATA_05C71B[v0 >> 1]) {
      if (!v0) {
        *(uint16 *)&io_sound_ch3 = 9;
        *(uint16 *)&timer_shake_layer1 = 32;
      }
      flag_on_off_switch = 0;
    } else {
      PointU16 *pt = get_PointU16(l1_l2_scroll_spr_speed, 0);
      uint16 y = pt[1].y;
      int v4 = v0 >> 1;
      if (y != kLayer2SpecialScrolling0B_Layer2OnOffControlled_DATA_05C71F[v4])
        pt[1].y = kLayer2SpecialScrolling0B_Layer2OnOffControlled_DATA_05C723[v4] + y;
      UpdateLayerPositionWithScrollSprite(6);
    }
  } else {
    if ((--l1_l2_scroll_spr_timer[1] & 0x80) != 0)
      l1_l2_scroll_spr_current_state[1] = v0;
    PointU16 *v1 = get_PointU16(misc_layer1_pos, 0);
    LOBYTE(v1[1].y) ^= 1;
    get_PointU16(l1_l2_scroll_spr_speed, 0)[1].y = 0;
  }
}

void Layer1SpecialScrolling0C_RegularAutoScroll() {  // 05c787
  camera_layer1_scrolling_direction = 2;
  camera_layer2_scrolling_direction = 2;
  uint8 v0 = scroll_spr_layer_index;
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_speed, scroll_spr_layer_index);
  uint16 x = pt->x;
  if (pt->x != kSpr0F3_RegularAutoScroll_MaxXSpeed[l1_l2_scroll_spr_scroll_type_index[scroll_spr_layer_index >> 2] >> 1])
    ++x;
  pt->x = x;
  if ((uint16)((camera_last_screen_horiz - 1) << 8) == get_PointU16(misc_layer1_pos, v0)->x)
    pt->x = 0;
  UpdateLayerPositionWithScrollSprite(v0);
}

void Layer2SpecialScrolling0D_FastBGScroll_Flagged() {  // 05c7bc
  if (flag_active_fast_background_scroll_generator)
    Layer2SpecialScrolling0D_FastBGScroll_NonFlagged();
}

void Layer2SpecialScrolling0D_FastBGScroll_NonFlagged() {  // 05c7c1
  camera_layer2_scrolling_direction = 2;
  PointU16 *pt = get_PointU16(l1_l2_scroll_spr_speed, 0);
  uint16 x = pt[1].x;
  if (x != 0x400)
    ++x;
  pt[1].x = x;
  UpdateLayerPositionWithScrollSprite(4);
  uint16 v2 = misc_layer1_xdisp;
  if (misc_layer1_xdisp >= 0x80)
    v2 = misc_layer1_xdisp | 0xFF00;
  PointU16 *v3 = get_PointU16(misc_layer1_pos, 0);
  v3[1].x += v2;
}

void Layer2SpecialScrolling0E_Layer2ScrollWhenTouched() {  // 05c81c
  PointU16 *v3;
  uint16 R0_W = l1_l2_scroll_spr_timer[1];
  uint8 v0 = 0;
  uint8 v1 = l1_l2_scroll_spr_timer[0];
  if (l1_l2_scroll_spr_timer[0] >= 8)
    v0 = 2;
  do {
    PointU16 *pt = get_PointU16(misc_layer1_pos, 0);
    v3 = pt;
    uint16 x = pt[1].x;
    int v5 = v1 >> 1;
    if (x >= kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C7F0[v5] &&
        x < kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C7FC[v5]) {
      *(uint16 *)l1_l2_scroll_spr_current_state = 0;
      pt[1].y = *(uint16 *)((int8 *)&kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C80E + v0);
      get_PointU16(l1_l2_scroll_spr_speed, 0)[1].y = 0;
      get_PointU16(l1_l2_scroll_spr_sub_pos, 0)[1].y = 0;
    }
    v1 += 2;
    --R0_W;
  } while (R0_W);
  l1_l2_scroll_spr_current_state[0] |= sprites_layer2_is_touched_flag;
  if (l1_l2_scroll_spr_current_state[0]) {
    int v6 = v0 >> 1;
    if (v3[1].y != kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C810[v6]) {
      uint16 y = get_PointU16(l1_l2_scroll_spr_speed, 0)[1].y;
      if (y != kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C814[v6])
        y += kLayer2SpecialScrolling0E_Layer2ScrollWhenTouched_DATA_05C818[v6];
      get_PointU16(l1_l2_scroll_spr_speed, 0)[1].y = y;
      UpdateLayerPositionWithScrollSprite(6);
    }
  }
}

void Layer2SpecialScrolling02_Layer2Smash() {  // 05c955
  Layer2SpecialScrolling02_Layer2Smash_05C95B(l1_l2_scroll_spr_scroll_type_index[0], l1_l2_scroll_spr_scroll_type_index[1]);
}

void Layer2SpecialScrolling02_Layer2Smash_05C95B(uint8 k, uint8 j) {  // 05c95b
  PointU16 *pt;
  do {
    pt = get_PointU16(misc_layer1_pos, 0);
    uint16 x = pt[1].x;
    int v4 = k >> 1;
    if (x >= kLayer2SpecialScrolling02_Layer2Smash_DATA_05C880[v4] && x < kLayer2SpecialScrolling02_Layer2Smash_DATA_05C8A4[v4]) {
      *(uint16 *)l1_l2_scroll_spr_current_state = (k >> 1) & 0xFE;
      pt[1].y = 193;
      *(uint16 *)l1_l2_scroll_spr_timer = 0;
    }
    k += 2;
  } while (--j);
  if (l1_l2_scroll_spr_timer[0]) {
    --l1_l2_scroll_spr_timer[0];
  } else {
    uint8 v5 = (uint8)(l1_l2_scroll_spr_current_state[1] + l1_l2_scroll_spr_current_state[0]) >> 1;
    int v6 = (uint8)(l1_l2_scroll_spr_current_state[1] + l1_l2_scroll_spr_current_state[0]) >> 1;
    if (((kLayer2SpecialScrolling02_Layer2Smash_DATA_05C8FE[v6] ^ (pt[1].y - kLayer2SpecialScrolling02_Layer2Smash_DATA_05C8C8[v6])) &
         0x8000) == 0) {
      pt[1].y = kLayer2SpecialScrolling02_Layer2Smash_DATA_05C8C8[v6];
      l1_l2_scroll_spr_timer[0] = kLayer2SpecialScrolling02_Layer2Smash_DATA_05C934[v5];
      uint8 v7 = l1_l2_scroll_spr_current_state[1] + 18;
      if ((uint8)(l1_l2_scroll_spr_current_state[1] + 18) >= 0x36) {
        io_sound_ch3 = 9;
        timer_shake_layer1 = 32;
        v7 = 0;
      }
      l1_l2_scroll_spr_current_state[1] = v7;
    } else {
      get_PointU16(l1_l2_scroll_spr_speed, 0)[1].y = kLayer2SpecialScrolling02_Layer2Smash_DATA_05C8FE[v6];
      UpdateLayerPositionWithScrollSprite(6);
    }
  }
}

void ProcessLevelEndRoutines() {  // 05cc07
  kProcessLevelEndRoutines_Ptrs05CC0E[pointer_current_overworld_process]();
}

void ShowCourseClearText() {  // 05cc66
  int16 v4;

  int8 v0 = 0;
  uint8 v1 = *(&player_mario_bonus_stars + player_current_character);
  while (v1 >= 0xA) {
    v1 -= (v1 < 0xA) + 10;
    ++v0;
  }
  if (v0 == counter_timer_tens && v0 == counter_timer_ones)
    ++misc_1up_handler;
  flag_disable_layer3_scroll = 1;
  mirror_bgmode_and_tile_size_setting |= 8;
  mirror_layer3_xpos = 0;
  mirror_layer3_ypos = 0;
  int16 v2 = 74;
  uint16 v3 = stripe_image_upload + 74;
  do {
    *(uint16 *)&stripe_image_upload_data[v3] = *(uint16 *)&kCourseClearText[(uint16)v2];
    v3 -= 2;
    v2 -= 2;
  } while (v2 >= 0);
  HIBYTE(v4) = HIBYTE(stripe_image_upload);
  uint16 v5 = stripe_image_upload;
  if (player_current_character) {
    for (uint16 i = 0; i != 5; ++i) {
      stripe_image_upload_data[v5 + 4] = kCourseClearText_Luigi[i];
      v5 += 2;
    }
  }
  uint16 v7 = 2;
  LOBYTE(v4) = stripe_image_upload + 4;
  int16 v8 = v4;
  do {
    stripe_image_upload_data[(uint16)v8 + 50] = *(&counter_timer_hundreds + v7--);
    v8 -= 2;
  } while (v8 >= 0);
  LOBYTE(v4) = stripe_image_upload;
  uint16 v9 = v4;
  do {
    if ((stripe_image_upload_data[v9 + 50] & 0xF) != 0)
      break;
    stripe_image_upload_data[v9 + 50] = -4;
    v9 += 2;
  } while (v9 != 4);
  uint16 R2_W = CalculateTimeBonusDigits();
  uint16 R0_W = 0;
  counter_level_end_score_tally = R2_W;
  AdjustTimeBonusDisplay(0x42, 0, R0_W, R2_W);
  for (uint8 j = 0; j != 8; j += 2) {
    if ((stripe_image_upload_data[j + 64] & 0xF) != 0)
      break;
    *(uint16 *)&stripe_image_upload_data[j + 64] = 0x38fc;
  }
  ++pointer_current_overworld_process;
  timer_display_bonus_stars = 40;
  LOBYTE(stripe_image_upload) = stripe_image_upload + 75;
}

void DisplayCourseClearTextBonusStars() {  // 05cd76
  if (counter_bonus_stars_earned) {
    if ((--timer_display_bonus_stars & 0x80) == 0)
      return;
    int8 v0 = 34;
    uint8 v1 = stripe_image_upload + 34;
    do
      stripe_image_upload_data[v1--] = kGotBonusStarsText_Bonus[(uint8)v0--];
    while (v0 >= 0);
    uint8 v2 = stripe_image_upload;
    uint8 v3 = 2 * (counter_bonus_stars_earned & 0xF);
    stripe_image_upload_data[(uint8)stripe_image_upload + 24] = kDisplayCourseClearTextBonusStars_DATA_05CD62[v3 + 1];
    stripe_image_upload_data[v2 + 32] = kDisplayCourseClearTextBonusStars_DATA_05CD62[v3];
    if ((uint8)(counter_bonus_stars_earned & 0xF0) >> 4) {
      uint8 v4 = 2 * ((uint8)(counter_bonus_stars_earned & 0xF0) >> 4);
      stripe_image_upload_data[v2 + 22] = kDisplayCourseClearTextBonusStars_DATA_05CD62[v4 + 1];
      stripe_image_upload_data[v2 + 30] = kDisplayCourseClearTextBonusStars_DATA_05CD62[v4];
    }
    LOBYTE(stripe_image_upload) = stripe_image_upload + 35;
  }
  if ((--timer_wait_before_score_tally & 0x80) != 0) {
    timer_display_bonus_stars = counter_bonus_stars_earned;
    ++pointer_current_overworld_process;
    io_sound_ch3 = 17;
  }
}

void AdjustTimeBonusDisplay(uint8 k, uint8 j, uint16 R0_W_, uint16 R2_W) {  // 05cdfd
  do {
    for (*(uint16 *)((int8 *)&stripe_image_upload + k) &= 0xFF00;; ++*(uint16 *)((int8 *)&stripe_image_upload + k)) {
      int v2 = j >> 1;
      bool v3 = R2_W >= kAdjustTimeBonusDisplay_DATA_05CDE9[v2 + 1];
      uint16 r6 = R2_W - kAdjustTimeBonusDisplay_DATA_05CDE9[v2 + 1];
      uint16 v4 = !v3 + kAdjustTimeBonusDisplay_DATA_05CDE9[v2];
      uint16 R4_W = R0_W_ - v4;
      if (R0_W_ < v4)
        break;
      R2_W = r6;
      R0_W_ = R4_W;
    }
    k += 2;
    j += 4;
  } while (j != 20);
}

uint16 CalculateTimeBonusDigits() {  // 05ce4c
  uint16 R0_W = kCalculateTimeBonusDigits_DATA_05CE3A[counter_timer_hundreds];
  R0_W += kCalculateTimeBonusDigits_DATA_05CE42[counter_timer_tens];
  R0_W += counter_timer_ones;
  uint16 mult = Mult8x8(R0_W, 0x32);
  uint8 R2_ = mult;
  uint8 R3_ = mult >> 8;
  R3_ += Mult8x8(R0_W >> 8, 0x32);
  return R2_ | R3_ << 8;
}

void GiveTimeBonusAndBonusStars() {  // 05ceca
  uint16 v7;
  uint16 R2_W = 0;

  uint8 v0 = 0;
  if (player_current_character)
    v0 = 3;
  uint8 v1 = 2;
  if (counter_level_end_score_tally) {
    if (counter_level_end_score_tally < 0x63)
      v1 = 0;
    counter_level_end_score_tally -= *(uint16 *)&kGiveTimeBonusAndBonusStars_DATA_05CEC2[v1];
    R2_W = counter_level_end_score_tally;
    uint16 v2 = *(uint16 *)&kGiveTimeBonusAndBonusStars_DATA_05CEC6[v1];
    uint32 t = (*(uint16 *)(&player_mario_score_hi + v0) << 16 | *(uint16 *)(&player_mario_score_lo + v0)) + v2;
    *(uint16 *)(&player_mario_score_lo + v0) = t;
    *(uint16 *)(&player_mario_score_hi + v0) = t >> 16;
  }
  if (counter_bonus_stars_earned) {
    if ((counter_global_frames & 3) == 0) {
      ++*(&player_mario_bonus_stars + player_current_character);
      if ((--counter_bonus_stars_earned & 0xF) == 15)
        counter_bonus_stars_earned -= 6;
    }
  }
  if (!counter_level_end_score_tally && !counter_bonus_stars_earned) {
    timer_wait_before_score_tally = 48;
    ++*(uint16 *)&pointer_current_overworld_process;
    io_sound_ch3 = 18;
  }
  uint8 v4 = 30;
  uint8 v5 = stripe_image_upload + 30;
  uint16 r10 = stripe_image_upload + 31;
  do {
    *(uint16 *)&stripe_image_upload_data[v5] = WORD(kNoBonusStarsText_Stars[v4]);
    v5 -= 2;
    v4 -= 2;
  } while ((v4 & 0x80) == 0);
  if (counter_level_end_score_tally) {
    uint16 R0_W = 0;
    AdjustTimeBonusDisplay(stripe_image_upload + 6, 0, R0_W, R2_W);
    R0_W = stripe_image_upload + 8;
    uint8 v6 = stripe_image_upload;
    do {
      if ((stripe_image_upload_data[v6 + 4] & 0xF) != 0)
        break;
      *(uint16 *)&stripe_image_upload_data[v6 + 4] = 0x38fc;
      v6 += 2;
    } while (v6 != (uint8)R0_W);
  }
  v7 = timer_display_bonus_stars;
  if (timer_display_bonus_stars) {
    LOBYTE(v7) = stripe_image_upload;
    uint16 v8 = v7;
    LOBYTE(v7) = 2 * (counter_bonus_stars_earned & 0xF);
    stripe_image_upload_data[v8 + 20] = kDisplayCourseClearTextBonusStars_DATA_05CD62[v7];
    stripe_image_upload_data[v8 + 28] = kDisplayCourseClearTextBonusStars_DATA_05CD62[v7 + 1];
    LOBYTE(v7) = (uint8)(counter_bonus_stars_earned & 0xF0) >> 3;
    if ((uint8)v7) {
      stripe_image_upload_data[v8 + 18] = kDisplayCourseClearTextBonusStars_DATA_05CD62[v7];
      stripe_image_upload_data[v8 + 26] = kDisplayCourseClearTextBonusStars_DATA_05CD62[v7 + 1];
    }
  }
  stripe_image_upload = r10;
}

void GiveTimeBonusAndBonusStars_Return() {  // 05cfe9
  ;
}

const uint8 *GetSpriteListPtr() {
  return kLvlSprBlob(Load24(ptr_sprite_list_data));
}

bool LoadLevel() {  // 05d796
  uint16 v1;
  int16 v5;
  uint16 v10;
  uint16 r14w;
  uint8 r1 = 0;
  uint8 r2 = 0;  // todo: what is R2 here?

  flag_override_no_yoshi_intro_for_midway_entrance = 0;
  if (in_yoshi_wings_bonus_area || flag_active_bonus_game)
    LoadLevel_05DBAC();
  if (counter_sublevels_entered) {
    uint8 v0 = ((misc_level_layout_flags & 1) != 0) ? HIBYTE(player_ypos) : HIBYTE(player_xpos);
    r14w = (ow_players_map[(uint8)player_current_characterx4 >> 2] != 0) << 8 | misc_subscreen_exit_entrance_number_lo[v0];
   
    r14w = LmHook_LoadLevelInfo_A(r14w, v0);

    if (flag_use_secondary_entrance) {
      uint16 j = r14w;
      r14w = (r14w & ~0xff) | kLevelInfo_05F800[j];
      uint8 r0 = kLevelInfo_05FA00[j];
      LOBYTE(player_ypos) = kLoadLevel_DATA_05D730[r0 & 0xF];
      HIBYTE(player_ypos) = kLoadLevel_DATA_05D740[r0 & 0xF];
      LOBYTE(mirror_current_layer1_ypos) = kLoadLevel_DATA_05D708[(r0 & 0x30) >> 4];
      LOBYTE(mirror_current_layer2_ypos) = kLoadLevel_DATA_05D70C[r0 >> 6];
      r1 = kLevelInfo_05FC00[j];
      LOBYTE(player_xpos) = kLoadLevel_DATA_05D750[r1 >> 5];
      HIBYTE(player_xpos) = kLoadLevel_DATA_05D758[r1 >> 5];
      if (HAS_LM_FEATURE(kLmFeature_LoadLevel)) {
        int tt = LmHook_LoadLevelInfo_E(j, r14w, r0, r1);
        if (tt < 0)
          return true;
        r2 = tt;
      } else {
        misc_level_header_entrance_settings = kLm5FE00[j] & 7;
      }
    }
  } else {
    v1 = 0;
    uint8 v2 = misc_intro_level_flag;
    if (!misc_intro_level_flag) {
      mirror_current_layer1_xpos = 0;
      mirror_current_layer2_xpos = 0;
      PointU16 *pt = get_PointU16(ow_players_grid_aligned_pos, player_current_characterx4);
      uint16 R0_W = pt->x & 0xF;
      uint16 R2_W = 16 * (pt->y & 0xF);
      R0_W |= 16 * (pt->x & 0x10);
      uint16 v4 = R0_W | R2_W | (32 * (pt->y & 0x10));
      v1 = (uint8)player_current_characterx4 >> 2;
      if ((ow_players_map[v1] & 0xF) != 0)
        v4 += 0x400;
      v2 = ow_level_number_of_each_tiletbl[v4];
      ow_level_number_lo = v2;
    }
    if (v2 >= 0x25)
      v2 -= 0x24;
    r14w = (ow_players_map[(uint8)v1] != 0) << 8 | v2;
    r14w = LmHook_LoadLevelInfo_C(r14w);
  }
  
  ptr_layer1_data = kLevelData_Layer1(r14w).ptr;
  ptr_layer2_data = kLevelData_Layer2(r14w).ptr;
  ptr_layer2_is_bg = kLevelData_Layer2_IsBg[r14w];

  if (g_lunar_magic)
    lunar_magic_FE = r14w + 1;

  HIBYTE(v5) = 0;
  ptr_sprite_list_data = (LongPtr){ 
    .bank = kLmSpritePtrBankByte[r14w],
    .addr = kLoadLevel_SpriteDataPtrs[r14w]
  };
  uint8 sprite_hdr = *GetSpriteListPtr();
  sprites_sprite_memory_setting = sprite_hdr & 0x1F;
  sprites_sprite_buoyancy_settings = sprite_hdr & 0xC0;
  uint8 v6 = kLevelInfo_05F000[r14w] >> 4;
  flag_layer2_horiz_scroll_level_setting = kLoadLevel_L2HorzScrollSettings[v6];
  flag_layer2_vert_scroll_level_setting = kLoadLevel_L2VertScrollSettings[v6];
  flag_layer1_horiz_scroll_level_setting = 1;
  misc_level_layer3_settings = (kLevelInfo_05F200[r14w] & 0xC0) >> 6;
  HIBYTE(mirror_current_layer1_ypos) = 0;
  HIBYTE(mirror_current_layer2_ypos) = 0;
  flag_disable_no_yoshi_intro = kLevelInfo_05F600[r14w] & 0x80;
  misc_level_layout_flags = (uint8)(kLevelInfo_05F600[r14w] & 0x60) >> 5;
  if (!flag_use_secondary_entrance) {
    v10 = kLevelInfo_05F000[r14w] & 0xF;
    player_ypos = PAIR16(kLoadLevel_DATA_05D740[v10], kLoadLevel_DATA_05D730[v10]);
    r2 = kLevelInfo_05F200[r14w];
    v10 = r2 & 7;
    player_xpos = PAIR16(kLoadLevel_DATA_05D758[v10], kLoadLevel_DATA_05D750[v10]);
    misc_level_header_entrance_settings = (uint8)(r2 & 0x38) >> 3;
    LmHook_ExpandLvlHdr(r14w);
    r2 = kLevelInfo_05F400[r14w];
    v10 = r2 & 3;
    mirror_current_layer2_ypos = kLoadLevel_DATA_05D70C[v10];
    LOBYTE(v10) = (uint8)(r2 & 0xC) >> 2;
    mirror_current_layer1_ypos = kLoadLevel_DATA_05D708[v10];
    r1 = kLevelInfo_05F600[r14w];
  }
  LmHook_LoadLevel(r14w);
  if ((misc_level_layout_flags & 1) != 0) {
    HIBYTE(player_ypos) = *ptr_layer1_data & 0x1F;
    camera_last_screen_vert = HIBYTE(player_ypos) + 1;
    flag_layer1_vert_scroll_level_setting = 1;
  }
  // disable the write to var13CD if LM
  if (counter_sublevels_entered || ((g_lunar_magic || (lm_var13CD = r2 >> 4)), flag_got_midpoint = 0,
                                    ow_current_event_number = kLoadLevel_DATA_05D608[ow_level_number_lo],
                                    (ow_level_tile_settings[ow_level_number_lo] & 0x40) == 0)) {
    r1 &= 0x1F;
    if ((misc_level_layout_flags & 1) != 0) {
      HIBYTE(player_ypos) = r1;
      HIBYTE(mirror_current_layer1_ypos) = r1;
      if (flag_layer2_vert_scroll_level_setting != 3)
        HIBYTE(mirror_current_layer2_ypos) = r1;
      flag_layer1_vert_scroll_level_setting = 1;
    } else {
      HIBYTE(player_xpos) = r1;
    }
  } else {
    flag_override_no_yoshi_intro_for_midway_entrance = ow_level_tile_settings[ow_level_number_lo] & 0x40;
    HIBYTE(player_xpos) = r2 >> 4;
  }
  uint8 v11;

  LmHook_LoadLevelB(ptr_layer1_data, r2, r14w);

  if (ow_level_number_lo < 0x52) {
    v11 = 4;
    uint8 v12 = ptr_layer1_data[4] & 0xF;
    while (v12 != kLoadLevel_LevelEntranceTileset[v11]) {
      if ((--v11 & 0x80) != 0)
        goto LABEL_47;
    }
  } else {
    v11 = 3;
  }
  if (!counter_sublevels_entered && !flag_show_player_start && !flag_disable_no_yoshi_intro) {
    if (ow_level_number_lo == 49 || ow_level_number_lo == 50 || ow_level_number_lo == 52 || ow_level_number_lo == 53 ||
        ow_level_number_lo == 64) {
      v11 = 5;
    }
    if (!flag_override_no_yoshi_intro_for_midway_entrance) {
      LOBYTE(player_ypos) = kLoadLevel_LevelEntranceYPos[v11];
      HIBYTE(player_ypos) = 1;
      player_xpos = 48;
      LOBYTE(mirror_current_layer1_ypos) = -64;
      LOBYTE(mirror_current_layer2_ypos) = -64;
      misc_level_header_entrance_settings = 0;
      ptr_sprite_list_data = (LongPtr){ .bank = 7, .addr = 0xc3ee };
      LmHook_LoadLevelInfo();
      uint8 sprite_hdr = *GetSpriteListPtr();
      sprites_sprite_memory_setting = sprite_hdr & 0x1F;
      sprites_sprite_buoyancy_settings = sprite_hdr & 0xC0;
      flag_layer2_horiz_scroll_level_setting = 0;
      flag_layer2_vert_scroll_level_setting = 0;
      flag_layer1_horiz_scroll_level_setting = 0;
      misc_level_layout_flags = 0;
      misc_level_layer3_settings = kLoadLevel_LevelEntranceLayer3[v11];
      ptr_layer1_data = kEntranceData_Layer1(v11).ptr;
      ptr_layer2_data = kEntranceData_Layer2(v11).ptr;
      ptr_layer2_is_bg = kEntranceData_Layer2_IsBg[v11];
    }
    misc_level_tileset_setting = kLoadLevel_LevelEntranceTileset[v11];
  }
LABEL_47:
  if (counter_sublevels_entered && !flag_active_bonus_game && ow_level_number_lo == 36)
    LoadLevel_HandleChocolateIsland2Gimmick();

  return false;
}

void LoadLevel_HandleChocolateIsland2Gimmick() {  // 05daef
  uint8 v1 = ptr_layer1_data[4] >> 6;
  uint8 v2;
  if (v1) {
    if (v1 == 1) {
      v2 = 10;
      if (sign8(counter_green_star_block - 22)) {
        v2 = 8;
        if (sign8(counter_green_star_block - 10))
          v2 = 6;
      }
    } else {
      if (v1 != 2) {
        Unreachable();
        return;
      }
      v2 = 12;
      if (!sign8(counter_timer_hundreds - 2) && (int8)(counter_timer_tens - 3) >= 0 &&
          (counter_timer_tens != 3 || !sign8(counter_timer_ones - 5))) {
        v2 = 14;
        if (!sign8(counter_timer_tens - 5))
          v2 = 16;
      }
    }
  } else {
    v2 = (counter_yoshi_coins_to_display != 4) ? 2 : 0;
  }

  int v3 = v2 >> 1;
  ptr_layer1_data = kChoclateIsland2_Layer1(v3).ptr;
  ptr_sprite_list_data.addr = kChoclateIsland2_SpritePtrs[v3];
  ptr_layer2_data = kChoclateIsland2_Layer2(v3).ptr;
  ptr_layer2_is_bg = kChoclateIsland2_Layer2_IsBg[v3];
  LmHook_LoadLevelInfo();
  uint8 sprite_hdr = *GetSpriteListPtr();
  sprites_sprite_memory_setting = sprite_hdr & 0x1F;
  sprites_sprite_buoyancy_settings = sprite_hdr & 0x80;
}

void LoadLevel_05DBAC() {  // 05dbac
  uint8 v0 = HIBYTE(player_xpos);
  if ((misc_level_layout_flags & 1) != 0)
    v0 = HIBYTE(player_ypos);
  misc_subscreen_exit_entrance_number_lo[v0] = kLoadLevel_BonusLevelSublevelsLo[in_yoshi_wings_bonus_area != 0];
  ++counter_sublevels_entered;
}

void LoadOverworldLifeCounter() {  // 05dbf2
  for (uint8 i = 8; (i & 0x80) == 0; --i)
    stripe_image_upload_data[i] = kLoadOverworldLifeCounter_DATA_05DBC9[i];
  PairU16 pair = HexToDec(players_lives[player_current_character != 0] + 1);
  int8 v2 = pair.first;
  uint8 v3 = pair.second;
  if ((uint8)v3) {
    stripe_image_upload_data[6] = v2 + 34;
    stripe_image_upload_data[7] = 57;
    v2 = v3;
  }
  stripe_image_upload_data[4] = v2 + 34;
  stripe_image_upload_data[5] = 57;
  LOBYTE(stripe_image_upload) = 8;
}

static const uint8 kSpr07B_GoalTape_BonusStarsEarned[32] = { 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x30, 0x40, 0x50,  };
static const uint8 kSpr07B_GoalTape_DATA_07F0C8[108] = { 0x0, 0x8, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x8, 0x10, 0xff, 0x8, 0x8, 0x8, 0x8, 0x8, 0xff, 0x0, 0x8, 0x10, 0x10, 0x8, 0x0, 0x0, 0x8, 0x10, 0xff, 0x0, 0x8, 0x10, 0x8, 0x10, 0x10, 0x0, 0x8, 0x10, 0xff, 0x0, 0x0, 0x10, 0x0, 0x10, 0x0, 0x8, 0x10, 0x10, 0xff, 0x0, 0x8, 0x10, 0x0, 0x0, 0x8, 0x10, 0x10, 0x0, 0x8, 0x10, 0xff, 0x8, 0x10, 0x0, 0x0, 0x8, 0x10, 0x0, 0x10, 0x0, 0x8, 0x10, 0xff, 0x0, 0x8, 0x10, 0x10, 0xc, 0x8, 0x8, 0xff, 0x0, 0x8, 0x10, 0x0, 0x10, 0x0, 0x8, 0x10, 0x0, 0x10, 0x0, 0x8, 0x10, 0xff, 0x0, 0x8, 0x10, 0x0, 0x10, 0x0, 0x8, 0x10, 0x10, 0x0, 0x8, 0x10, 0xff,  };
static const uint8 kSpr07B_GoalTape_DATA_07F134[108] = { 0x0, 0x0, 0x0, 0x8, 0x8, 0x10, 0x10, 0x18, 0x18, 0x20, 0x20, 0x20, 0xff, 0x0, 0x8, 0x10, 0x18, 0x20, 0xff, 0x0, 0x0, 0x0, 0x8, 0x10, 0x18, 0x20, 0x20, 0x20, 0xff, 0x0, 0x0, 0x8, 0x10, 0x10, 0x18, 0x20, 0x20, 0x20, 0xff, 0x0, 0x8, 0x8, 0x10, 0x10, 0x18, 0x18, 0x18, 0x20, 0xff, 0x0, 0x0, 0x0, 0x8, 0x10, 0x10, 0x10, 0x18, 0x20, 0x20, 0x20, 0xff, 0x0, 0x0, 0x8, 0x10, 0x10, 0x10, 0x18, 0x18, 0x20, 0x20, 0x20, 0xff, 0x0, 0x0, 0x0, 0x8, 0x10, 0x18, 0x20, 0xff, 0x0, 0x0, 0x0, 0x8, 0x8, 0x10, 0x10, 0x10, 0x18, 0x18, 0x20, 0x20, 0x20, 0xff, 0x0, 0x0, 0x0, 0x8, 0x8, 0x10, 0x10, 0x10, 0x18, 0x20, 0x20, 0x20, 0xff,  };
static const uint8 kSpr07B_GoalTape_DATA_07F1A0[10] = { 0x0, 0xd, 0x13, 0x1d, 0x27, 0x31, 0x3d, 0x49, 0x51, 0x5f,  };
static const uint8 kSpr07B_GoalTape_DATA_07F24E[4] = { 0x66, 0x66, 0x6e, 0xff,  };

void Spr07B_GoalTape_BonusStarNumbersDraw(uint8 k) {  // 07f1ca
  uint16 R4_ = spr_decrementing_table1540[k];
  uint8 R2_ = 0;
  uint8 v2 = kSpr07B_GoalTape_BonusStarsEarned[spr_table1594[k] >> 2];
  if (v2 >> 4)
    Spr07B_GoalTape_07F200(kSpr07B_GoalTape_DATA_07F1A0[v2 >> 4], 0x20, R2_, R4_);
  uint8 v1 = kSpr07B_GoalTape_DATA_07F1A0[v2 & 0xF];
  R2_ = 32;
  Spr07B_GoalTape_07F200(v1, 0x54, R2_, R4_);
}

uint8 Spr07B_GoalTape_07F200(uint8 k, uint8 j, uint16 R2, uint16 R4_) {  // 07f200
  while (1) {
    int8 v2 = kSpr07B_GoalTape_DATA_07F0C8[k];
    if (v2 < 0)
      break;
    OamEnt *oam = get_OamEnt(oam_buf, j);
    oam->xpos = R2 + v2 + 100;
    oam->ypos = kSpr07B_GoalTape_DATA_07F134[k] + 64;
    uint8 v4 = -17;
    if (R4_ < 0x10)
      v4 = kSpr07B_GoalTape_DATA_07F24E[R4_ >> 2];
    oam->charnum = v4;
    oam->flags = (counter_global_frames >> 1) & 0xE | 0x30;
    sprites_oamtile_size_buffer[j >> 2] = 0;
    j += 4;
    ++k;
  }
  return j;
}

void Spr07B_GoalTape_GiveBonusStars(uint8 k) {  // 07f252
  counter_bonus_stars_earned = kSpr07B_GoalTape_BonusStarsEarned[spr_table1594[k] >> 2];
  if (counter_bonus_stars_earned == 80)
    GivePoints(k, 0xA);
}

