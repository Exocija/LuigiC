#pragma once
#include <stdint.h>
#include <stdbool.h>

// Constants for SMW Inputs
#define AI_KEY_B      0x001
#define AI_KEY_Y      0x002
#define AI_KEY_SELECT 0x004
#define AI_KEY_START  0x008
#define AI_KEY_UP     0x010
#define AI_KEY_DOWN   0x020
#define AI_KEY_LEFT   0x040
#define AI_KEY_RIGHT  0x080
#define AI_KEY_A      0x100
#define AI_KEY_X      0x200
#define AI_KEY_L      0x400
#define AI_KEY_R      0x800

#include "common_cpu_infra.h"

#define AI_MAX_DEPTH 1000
#define AI_MAX_NODES 6000
#define AI_NUM_ACTIONS 8

typedef struct {
    uint16_t x, y;
} AiPoint;

typedef struct {
    AiPoint points[AI_MAX_DEPTH];
    int length;
    uint16_t input_sequence[AI_MAX_DEPTH];
    int current_step;
} AiPath;

extern AiPath g_ai_best_path;

// Optimized Node for Deep Search
typedef struct {
    uint8_t *ram_state;   
    int parent_index;
    int depth;
    uint16_t input_used;  // Input that led to this node
    uint16_t macro_frames; // How many frames this input was held
    AiPoint pos;
    float cost_f;         
} AiNode;

extern bool g_ai_active;
extern bool g_ai_capture_inputs;

typedef struct {
    uint16_t level_id;
    uint16_t inputs[10000];
    uint16_t x_pos[10000]; // Recorded X progress
    int length;
} AiStrategy;

void AiEngine_Init(void);
uint16_t AiEngine_GetBestAction(void);
void AiEngine_SaveStrategy(void);
void AiEngine_LoadStrategy(void);
void AiEngine_RecordFrame(uint16_t input, uint16_t x);