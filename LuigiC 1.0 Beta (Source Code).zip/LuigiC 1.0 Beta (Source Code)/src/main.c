#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <SDL.h>
#ifdef _WIN32
#include "platform/win32/volume_control.h"
#include <direct.h>
#include <windows.h>
#include <commdlg.h>
#include <SDL_syswm.h>
#else
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#endif

#include "assets/smw_assets.h"
#include "snes/ppu.h"
#include "types.h"
#include "smw_rtl.h"
#include "common_cpu_infra.h"
#include "config.h"
#include "util.h"
#include "smw_spc_player.h"
#include "snes/snes.h"
#ifdef __SWITCH__
#include "switch_impl.h"
#endif
#include "variables.h"
#include "AiEngine.h"


bool g_ai_active = false;
bool g_menu_open = false;
int g_menu_cursor = 0;
static const uint8 kFullFont[128][5] = {
  ['0']={0x3e, 0x51, 0x49, 0x45, 0x3e}, ['1']={0x00, 0x42, 0x7f, 0x40, 0x00}, ['2']={0x42, 0x61, 0x51, 0x49, 0x46},
  ['3']={0x21, 0x41, 0x45, 0x4b, 0x31}, ['4']={0x18, 0x14, 0x12, 0x7f, 0x10}, ['5']={0x27, 0x45, 0x45, 0x45, 0x39},
  ['6']={0x3c, 0x4a, 0x49, 0x49, 0x30}, ['7']={0x01, 0x71, 0x09, 0x05, 0x03}, ['8']={0x36, 0x49, 0x49, 0x49, 0x36},
  ['9']={0x06, 0x49, 0x49, 0x29, 0x1e}, [':']={0x00, 0x36, 0x36, 0x00, 0x00}, [';']={0x00, 0x56, 0x36, 0x00, 0x00},
  ['A']={0x7e, 0x11, 0x11, 0x11, 0x7e}, ['B']={0x7f, 0x49, 0x49, 0x49, 0x36}, ['C']={0x3e, 0x41, 0x41, 0x41, 0x22},
  ['D']={0x7f, 0x41, 0x41, 0x22, 0x1c}, ['E']={0x7f, 0x49, 0x49, 0x49, 0x41}, ['F']={0x7f, 0x09, 0x09, 0x09, 0x01},
  ['G']={0x3e, 0x41, 0x49, 0x49, 0x7a}, ['H']={0x7f, 0x08, 0x08, 0x08, 0x7f}, ['I']={0x00, 0x41, 0x7f, 0x41, 0x00},
  ['J']={0x20, 0x40, 0x41, 0x3f, 0x01}, ['K']={0x7f, 0x08, 0x14, 0x22, 0x41}, ['L']={0x7f, 0x40, 0x40, 0x40, 0x40},
  ['M']={0x7f, 0x02, 0x0c, 0x02, 0x7f}, ['N']={0x7f, 0x04, 0x08, 0x10, 0x7f}, ['O']={0x3e, 0x41, 0x41, 0x41, 0x3e},
  ['P']={0x7f, 0x09, 0x09, 0x09, 0x06}, ['Q']={0x3e, 0x41, 0x51, 0x21, 0x5e}, ['R']={0x7f, 0x09, 0x19, 0x29, 0x46},
  ['S']={0x46, 0x49, 0x49, 0x49, 0x31}, ['T']={0x01, 0x01, 0x7f, 0x01, 0x01}, ['U']={0x3f, 0x40, 0x40, 0x40, 0x3f},
  ['V']={0x1f, 0x20, 0x40, 0x20, 0x1f}, ['W']={0x3f, 0x40, 0x38, 0x40, 0x3f}, ['X']={0x63, 0x14, 0x08, 0x14, 0x63},
  ['Y']={0x07, 0x08, 0x70, 0x08, 0x07}, ['Z']={0x61, 0x51, 0x49, 0x45, 0x43}, [' ']={0x00, 0x00, 0x00, 0x00, 0x00},
  ['-']={0x00, 0x08, 0x08, 0x08, 0x00},
};

static void DrawPixel(uint8 *pixel_buffer, int pitch, int x, int y, uint32 color, int scale) {
  if (x < 0 || x >= 256 || y < 0 || y >= 224) return;
  for (int dy = 0; dy < scale; dy++) {
    uint32 *row = (uint32 *)(pixel_buffer + (y * scale + dy) * pitch);
    for (int dx = 0; dx < scale; dx++) row[x * scale + dx] = color;
  }
}

static void RenderChar(uint8 *pixel_buffer, int pitch, int x, int y, char c, uint32 color, int scale) {
  if ((uint8)c >= 128) return;
  const uint8 *p = kFullFont[(uint8)c];
  for (int ix = 0; ix < 5; ix++) {
    uint8 v = p[ix];
    for (int iy = 0; iy < 8; iy++) {
      if (v & (1 << iy)) DrawPixel(pixel_buffer, pitch, x + ix, y + iy, color, scale);
    }
  }
}

static void RenderString(uint8 *pixel_buffer, int pitch, int x, int y, const char *s, uint32 color, int scale) {
  int x_off = 0;
  while (*s) {
    RenderChar(pixel_buffer, pitch, x + x_off, y, *s++, color, scale);
    x_off += 6;
  }
}

static const char* GetSpriteName(uint8 type, char *buf) {
  switch(type) {
    case 0x00: case 0x01: case 0x02: case 0x03: return "KOOPA";
    case 0x04: case 0x05: case 0x06: case 0x07: case 0x08: return "KOOPA";
    case 0x09: case 0x0A: case 0x0B: case 0x0C: return "SHELL";
    case 0x0D: return "GOOMBA";
    case 0x0E: return "PIRANHA";
    case 0x11: return "BUZZY";
    case 0x12: return "SPINY";
    case 0x13: return "SPINY_EGG";
    case 0x14: return "FISH";
    case 0x1A: return "THWMP";
    case 0x1B: return "THWMP_S";
    case 0x1D: return "BULLET";
    case 0x1E: return "BILL_G";
    case 0x21: return "COIN";
    case 0x26: case 0x27: return "MAGIKOOPA";
    case 0x29: return "KOOPA_KID";
    case 0x35: return "YOSHI";
    case 0x3E: return "P_SWITCH";
    case 0x41: return "MUSHROOM";
    case 0x42: return "FLOWER";
    case 0x43: return "STAR";
    case 0x44: return "P_BALLOON";
    case 0x45: return "1UP";
    case 0x48: return "WINGS";
    case 0x51: return "NINJI";
    case 0x74: return "MUSH_PLT";
    case 0x75: return "MUSH_PLT";
    case 0x76: return "MUSH_PLT";
    case 0x77: return "MUSH_PLT";
    case 0x78: return "MUSH_PLT";
    case 0x91: case 0x92: case 0x93: case 0x94: case 0x95: return "CHUCK";
    case 0xA2: return "MECHA_K";
    case 0xB9: return "BILL_B";
    case 0xC5: return "EGG";
    case 0xDF: return "GOAL";
    default:
      sprintf(buf, "SPR_%02X", type);
      return buf;
  }
}

static const char* GetTileName(uint8 lo) {
  if (lo >= 0x11 && lo <= 0x6D) return "FLOOR";
  if (lo == 0x04 || lo == 0x05) return "LAVA";
  if (lo == 0x01 || lo == 0x02) return "WATER";
  if (lo == 0x2B || lo == 0x21) return "ITEM";
  return NULL;
}

// =========================================================
// ORIGINAL SYSTEM TYPES & GLOBALS
// =========================================================
typedef struct GamepadInfo {
  uint32 modifiers;
  SDL_JoystickID joystick_id;
  uint8 index;
  uint8 axis_buttons;
  uint16 last_cmd[kGamepadBtn_Count];
  Sint16 last_axis_x, last_axis_y;
} GamepadInfo;

static void SDLCALL AudioCallback(void *userdata, Uint8 *stream, int len);
static void LoadAssets();
static void SwitchDirectory();
static void RenderNumber(uint8 *dst, size_t pitch, int n, uint8 big);
static void OpenOneGamepad(int i);
static uint32 GetActiveControllers(void);
static void HandleVolumeAdjustment(int volume_adjustment);
static void HandleGamepadAxisInput(GamepadInfo *gi, int axis, Sint16 value);
static int RemapSdlButton(int button);
static void HandleGamepadInput(GamepadInfo *gi, int button, bool pressed);
static void HandleInput(int keyCode, int keyMod, bool pressed);
static void HandleCommand(uint32 j, bool pressed);
void OpenGLRenderer_Create(struct RendererFuncs *funcs);

bool g_debug_flag;
bool g_want_dump_memmap_flags;
bool g_new_ppu = true;
bool g_other_image = true;
struct SpcPlayer *g_spc_player;
static uint8_t g_pixels[256 * 4 * 240];
static uint8_t g_my_pixels[256 * 4 * 240];
int g_got_mismatch_count;

enum {
  kDefaultFullscreen = 0,
  kMaxWindowScale = 10,
  kDefaultFreq = 44100,
  kDefaultChannels = 2,
  kDefaultSamples = 2048,
};

static const char kWindowTitle[] = "SMW";
static uint32 g_win_flags = SDL_WINDOW_RESIZABLE;
static SDL_Window *g_window;
static uint8 g_paused, g_turbo, g_replay_turbo = true, g_cursor = true;
static uint8 g_current_window_scale;
static uint32 g_input_state;
static bool g_display_perf;
static int g_curr_fps;
static int g_ppu_render_flags = 0;
static int g_snes_width, g_snes_height;
static int g_sdl_audio_mixer_volume = SDL_MIX_MAXVOLUME;
static struct RendererFuncs g_renderer_funcs;
static GamepadInfo g_gamepad[2];
extern Snes *g_snes;

void NORETURN Die(const char *error) {
  SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, kWindowTitle, error, NULL);
  fprintf(stderr, "Error: %s\n", error);
  exit(1);
}

void Warning(const char *error) {
  SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_WARNING, kWindowTitle, error, NULL);
  fprintf(stderr, "Warning: %s\n", error);
}

static GamepadInfo *GetGamepadInfo(SDL_JoystickID id) {
  return (g_gamepad[0].joystick_id == id) ? &g_gamepad[0] :
    (g_gamepad[1].joystick_id == id) ? &g_gamepad[1] : NULL;
}

void ChangeWindowScale(int scale_step) {
  if ((SDL_GetWindowFlags(g_window) & (SDL_WINDOW_FULLSCREEN_DESKTOP | SDL_WINDOW_FULLSCREEN | SDL_WINDOW_MINIMIZED | SDL_WINDOW_MAXIMIZED)) != 0)
    return;
  int screen = SDL_GetWindowDisplayIndex(g_window);
  if (screen < 0) screen = 0;
  int max_scale = kMaxWindowScale;
  SDL_Rect bounds;
  int bt = -1, bl, bb, br;
  if (SDL_GetDisplayUsableBounds(screen, &bounds) == 0) {
    if (SDL_GetWindowBordersSize(g_window, &bt, &bl, &bb, &br) != 0) {
      bl = br = bb = 1; bt = 31;
    }
    int mw = (bounds.w - bl - br + g_snes_width / 4) / g_snes_width;
    int mh = (bounds.h - bt - bb + g_snes_height / 4) / g_snes_height;
    max_scale = IntMin(mw, mh);
  }
  int new_scale = IntMax(IntMin(g_current_window_scale + scale_step, max_scale), 1);
  g_current_window_scale = new_scale;
  SDL_SetWindowSize(g_window, new_scale * g_snes_width, new_scale * g_snes_height);
}

#define RESIZE_BORDER 20
static SDL_HitTestResult HitTestCallback(SDL_Window *win, const SDL_Point *pt, void *data) {
  int w, h; SDL_GetWindowSize(win, &w, &h);
  if (pt->y < RESIZE_BORDER) return (pt->x < RESIZE_BORDER) ? SDL_HITTEST_RESIZE_TOPLEFT : (pt->x >= w - RESIZE_BORDER) ? SDL_HITTEST_RESIZE_TOPRIGHT : SDL_HITTEST_RESIZE_TOP;
  return SDL_HITTEST_NORMAL;
}

void RtlDrawPpuFrame(uint8 *pixel_buffer, size_t pitch, uint32 render_flags) {
  g_rtl_game_info->draw_ppu_frame();
  uint8 *ppu_pixels = g_other_image ? g_my_pixels : g_pixels;
  for (size_t y = 0, y_end = g_snes_height; y < y_end; y++)
    memcpy((uint8 *)pixel_buffer + y * pitch, ppu_pixels + y * 256 * 4, 256 * 4);
}

static void DrawPpuFrameWithPerf(void) {
  int render_scale = PpuGetCurrentRenderScale(g_ppu, g_ppu_render_flags);
  uint8 *pixel_buffer = 0; int pitch = 0;
  g_renderer_funcs.BeginDraw(g_snes_width * render_scale, g_snes_height * render_scale, &pixel_buffer, &pitch);
  
  if (g_display_perf || g_config.display_perf_title) {
    static float history[64], average; static int history_pos;
    uint64 before = SDL_GetPerformanceCounter();
    RtlDrawPpuFrame(pixel_buffer, pitch, g_ppu_render_flags);
    uint64 after = SDL_GetPerformanceCounter();
    float v = (double)SDL_GetPerformanceFrequency() / (after - before);
    average += v - history[history_pos]; history[history_pos] = v; history_pos = (history_pos + 1) & 63;
    g_curr_fps = average * (1.0f / 64);
  } else {
    RtlDrawPpuFrame(pixel_buffer, pitch, g_ppu_render_flags);
  }

  if (g_display_perf) {
    RenderNumber(pixel_buffer + 5 * render_scale * pitch + 5 * render_scale * 4, pitch, g_curr_fps, render_scale == 4);
    if (g_ai_active) {
      uint16_t cam_x = mirror_current_layer1_xpos;
      uint16_t cam_y = mirror_current_layer1_ypos;
      uint16_t player_x = g_ram[0x94] | (g_ram[0x95] << 8);
      uint16_t player_y = g_ram[0x96] | (g_ram[0x97] << 8);

      for (int dy = -64; dy <= 64; dy += 16) {
        for (int dx = -64; dx <= 96; dx += 16) {
          uint16_t tx = (player_x + dx) & ~0xF; uint16_t ty = (player_y + dy) & ~0xF;
          uint16_t tile_idx = ((tx >> 4) & 0xF) | (((ty >> 4) & 0xF) << 4) | (((tx >> 4) & 0xFFF0) << 4);
          uint8 lo = blocks_map16_table_lo[tile_idx % 0x8000];
          if (GetTileName(lo)) {
            for (int iy = 0; iy < 16; iy++) {
              for (int ix = 0; ix < 16; ix++) {
                int sx = tx - cam_x + ix, sy = ty - cam_y + iy;
                if (sx < 0 || sx >= 256 || sy < 0 || sy >= 224) continue;
                uint32 *p = &((uint32 *)(pixel_buffer + (sy * render_scale) * pitch))[sx * render_scale];
                for (int rs_y = 0; rs_y < render_scale; rs_y++) {
                  uint32 *row = (uint32 *)(pixel_buffer + (sy * render_scale + rs_y) * pitch);
                  for (int rs_x = 0; rs_x < render_scale; rs_x++) {
                    uint32 *px = &row[sx * render_scale + rs_x];
                    *px = ((*px & 0xFEFEFE) >> 1) + 0x400000;
                  }
                }
              }
            }
          }
        }
      }
      for (int i = 0; i < 12; i++) {
        if (g_ram[0x14C8 + i] >= 8) {
          uint16 sx = g_ram[0x00E4 + i] | (g_ram[0x14E0 + i] << 8);
          uint16 sy = g_ram[0x00D8 + i] | (g_ram[0x14D4 + i] << 8);
          DrawPixel(pixel_buffer, pitch, sx - cam_x, sy - cam_y, 0xFFFF00, render_scale);
          char s_buf[16];
          RenderString(pixel_buffer, pitch, sx - cam_x, sy - cam_y - 8, GetSpriteName(g_ram[0x9E + i], s_buf), 0xFFFF44, render_scale);
        }
      }
      for (int i = 0; i < g_ai_best_path.length - 1; i++) {
        int x1 = g_ai_best_path.points[i].x - cam_x, y1 = g_ai_best_path.points[i].y - cam_y;
        int x2 = g_ai_best_path.points[i+1].x - cam_x, y2 = g_ai_best_path.points[i+1].y - cam_y;
        for(int s=0; s<=8; s++) {
          int lx = x1 + (x2-x1)*s/8, ly = y1 + (y2-y1)*s/8;
          DrawPixel(pixel_buffer, pitch, lx, ly, 0x00FF00, render_scale);
        }
      }
    }
  }
  if (g_menu_open) {
    int mx = 40, my = 60;
    int scale = render_scale;
    // Semi-transparent background box
    for (int y = my - 10; y < my + 80; y++) {
      for (int x = mx - 10; x < mx + 180; x++) {
        if (x < 0 || x >= 256 || y < 0 || y >= 224) continue;
        uint32 *px = (uint32 *)(pixel_buffer + (y * scale) * pitch + (x * scale) * 4);
        for (int dy = 0; dy < scale; dy++) {
          uint32 *row = (uint32 *)(pixel_buffer + (y * scale + dy) * pitch);
          for (int dx = 0; dx < scale; dx++) {
            uint32 *p = &row[x * scale + dx];
            *p = (*p & 0xFEFEFE) >> 1; // Darken
          }
        }
      }
    }
    RenderString(pixel_buffer, pitch, mx, my, "MAP MENU (Q)", 0xFFFFFF, scale);
    RenderString(pixel_buffer, pitch, mx, my + 20, g_menu_cursor == 0 ? "> SAVE SNAPSHOT" : "  SAVE SNAPSHOT", 0xFFFF00, scale);
    RenderString(pixel_buffer, pitch, mx, my + 30, g_menu_cursor == 1 ? "> LOAD SNAPSHOT" : "  LOAD SNAPSHOT", 0xFFFF00, scale);
    
    RenderString(pixel_buffer, pitch, mx, my + 50, "UP/DOWN: NAVIGATE", 0xAAAAAA, scale);
    RenderString(pixel_buffer, pitch, mx, my + 60, "ENTER: SELECT", 0xAAAAAA, scale);
  }
  if (g_got_mismatch_count) RenderNumber(pixel_buffer + pitch * render_scale, pitch, g_got_mismatch_count, render_scale == 4);
  g_renderer_funcs.EndDraw();
}

static SDL_mutex *g_audio_mutex;
static uint8 *g_audiobuffer, *g_audiobuffer_cur, *g_audiobuffer_end;
static int g_frames_per_block;
static uint8 g_audio_channels;
static SDL_AudioDeviceID g_audio_device;

void RtlApuLock(void) { SDL_LockMutex(g_audio_mutex); }
void RtlApuUnlock(void) { SDL_UnlockMutex(g_audio_mutex); }

static void SDLCALL AudioCallback(void *userdata, Uint8 *stream, int len) {
  if (SDL_LockMutex(g_audio_mutex)) Die("Mutex lock failed!");
  while (len != 0) {
    if (g_audiobuffer_end - g_audiobuffer_cur == 0) {
      RtlRenderAudio((int16 *)g_audiobuffer, g_frames_per_block, g_audio_channels);
      g_audiobuffer_cur = g_audiobuffer;
      g_audiobuffer_end = g_audiobuffer + g_frames_per_block * g_audio_channels * sizeof(int16);
    }
    int n = IntMin(len, g_audiobuffer_end - g_audiobuffer_cur);
    if (g_sdl_audio_mixer_volume == SDL_MIX_MAXVOLUME) memcpy(stream, g_audiobuffer_cur, n);
    else { SDL_memset(stream, 0, n); SDL_MixAudioFormat(stream, g_audiobuffer_cur, AUDIO_S16, n, g_sdl_audio_mixer_volume); }
    g_audiobuffer_cur += n; stream += n; len -= n;
  }
  SDL_UnlockMutex(g_audio_mutex);
}

static SDL_Renderer *g_renderer;
static SDL_Texture *g_texture;
static SDL_Rect g_sdl_renderer_rect;

static bool SdlRenderer_Init(SDL_Window *window) {
  g_renderer = SDL_CreateRenderer(window, -1, g_config.output_method == kOutputMethod_SDLSoftware ? SDL_RENDERER_SOFTWARE : SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
  if (g_renderer == NULL) return false;
  g_texture = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, g_snes_width, g_snes_height);
  return g_texture != NULL;
}
static void SdlRenderer_Destroy(void) { SDL_DestroyTexture(g_texture); SDL_DestroyRenderer(g_renderer); }
static void SdlRenderer_BeginDraw(int width, int height, uint8 **pixels, int *pitch) {
  g_sdl_renderer_rect.w = width; g_sdl_renderer_rect.h = height;
  SDL_LockTexture(g_texture, &g_sdl_renderer_rect, (void **)pixels, pitch);
}
static void SdlRenderer_EndDraw(void) {
  SDL_UnlockTexture(g_texture); SDL_RenderClear(g_renderer);
  SDL_RenderCopy(g_renderer, g_texture, &g_sdl_renderer_rect, NULL);
  SDL_RenderPresent(g_renderer);
}
static const struct RendererFuncs kSdlRendererFuncs = { &SdlRenderer_Init, &SdlRenderer_Destroy, &SdlRenderer_BeginDraw, &SdlRenderer_EndDraw };

void MkDir(const char *s) {
#if defined(_WIN32)
  _mkdir(s);
#else
  mkdir(s, 0755);
#endif
}

#undef main
int main(int argc, char** argv) {
#ifdef __SWITCH__
  SwitchImpl_Init();
#endif
  argc--, argv++;
  const char *config_file = NULL;
  if (argc >= 2 && strcmp(argv[0], "--config") == 0) { config_file = argv[1]; argc -= 2, argv += 2; }
  else { SwitchDirectory(); }
  if (argc >= 1 && strcmp(argv[0], "--debug") == 0) { g_debug_flag = true; argc -= 1, argv += 1; }
  ParseConfigFile(config_file); LoadAssets();
  g_gamepad[0].joystick_id = g_gamepad[1].joystick_id = -1;
  g_snes_width = (g_config.extended_aspect_ratio * 2 + 256); g_snes_height = 224;
  g_ppu_render_flags = g_config.new_renderer * kPpuRenderFlags_NewRenderer | g_config.extend_y * kPpuRenderFlags_Height240 | g_config.no_sprite_limits * kPpuRenderFlags_NoSpriteLimits;
  if (g_config.fullscreen == 1) g_win_flags ^= SDL_WINDOW_FULLSCREEN_DESKTOP;
  else if (g_config.fullscreen == 2) g_win_flags ^= SDL_WINDOW_FULLSCREEN;
  g_current_window_scale = (g_config.window_scale == 0) ? 2 : IntMin(g_config.window_scale, kMaxWindowScale);
  if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER) != 0) return 1;
  int window_width = g_current_window_scale * g_snes_width, window_height = g_current_window_scale * g_snes_height;
  if (g_config.output_method == kOutputMethod_OpenGL) { g_win_flags |= SDL_WINDOW_OPENGL; OpenGLRenderer_Create(&g_renderer_funcs); }
  else { g_renderer_funcs = kSdlRendererFuncs; }
  if (argv[0]) { size_t size; kRom = ReadWholeFile(argv[0], &size); kRom_SIZE = (uint32)size; }
  SnesInit(kRom, kRom_SIZE);
  g_window = SDL_CreateWindow(kWindowTitle, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, window_width, window_height, g_win_flags);
  SDL_SetWindowHitTest(g_window, HitTestCallback, NULL);
  g_renderer_funcs.Initialize(g_window);
  g_audio_mutex = SDL_CreateMutex();
  if (g_rtl_game_info->game_id == kGameID_SMW) g_spc_player = SmwSpcPlayer_Create();
  else g_spc_player = SmasSpcPlayer_Create();
  g_spc_player->initialize(g_spc_player);
  SDL_AudioSpec want = { 0 }, have; want.freq = g_config.audio_freq; want.format = AUDIO_S16; want.channels = 2; want.samples = g_config.audio_samples; want.callback = &AudioCallback;
  g_audio_device = SDL_OpenAudioDevice(NULL, 0, &want, &have, 0);
  g_audio_channels = 2; g_frames_per_block = (534 * have.freq) / 32000;
  g_audiobuffer = (uint8 *)calloc(g_frames_per_block * have.channels * sizeof(int16), 1);
  PpuBeginDrawing(g_snes->ppu, g_pixels, 256 * 4, 0); PpuBeginDrawing(g_my_ppu, g_my_pixels, 256 * 4, 0);
  MkDir("playthrough"); MkDir("saves"); RtlReadSram();
  for (int i = 0; i < SDL_NumJoysticks(); i++) OpenOneGamepad(i);
  if (g_config.autosave) HandleCommand(kKeys_Load + 0, true);
  RtlReset(0); AiEngine_Init();
  bool running = true;
  uint32 lastTick = SDL_GetTicks();
  uint32 curTick = 0;
  uint32 frameCtr = 0;
  uint8 audiopaused = true;
  GamepadInfo *gi;

  while (running) {
    SDL_Event event;

    while (SDL_PollEvent(&event)) {
      switch (event.type) {
      case SDL_CONTROLLERDEVICEADDED:
        OpenOneGamepad(event.cdevice.which);
        break;
      case SDL_CONTROLLERDEVICEREMOVED:
        gi = GetGamepadInfo(event.cdevice.which);
        if (gi) {
          memset(gi, 0, sizeof(GamepadInfo));
          gi->joystick_id = -1;
        }
        break;
      case SDL_CONTROLLERAXISMOTION:
        gi = GetGamepadInfo(event.caxis.which);
        if (gi)
          HandleGamepadAxisInput(gi, event.caxis.axis, event.caxis.value);
        break;
      case SDL_CONTROLLERBUTTONDOWN:
      case SDL_CONTROLLERBUTTONUP: {
        gi = GetGamepadInfo(event.cbutton.which);
        if (gi) {
          int b = RemapSdlButton(event.cbutton.button);
          if (b >= 0)
            HandleGamepadInput(gi, b, event.type == SDL_CONTROLLERBUTTONDOWN);
        }
        break;
      }
      case SDL_KEYDOWN:
        HandleInput(event.key.keysym.sym, event.key.keysym.mod, true);
        break;
      case SDL_KEYUP:
        HandleInput(event.key.keysym.sym, event.key.keysym.mod, false);
        break;
      case SDL_QUIT:
        running = false;
        break;
      }
    }

    if (g_paused != audiopaused) {
      audiopaused = g_paused;
      if (g_audio_device)
        SDL_PauseAudioDevice(g_audio_device, audiopaused);
    }

    if (g_paused) {
      SDL_Delay(16);
      continue;
    }

    uint32 inputs = g_input_state | g_gamepad[0].axis_buttons | g_gamepad[1].axis_buttons << 12;
    if (g_ai_active) inputs = (inputs & ~0xfff) | AiEngine_GetBestAction();
    RtlRunFrame(inputs | GetActiveControllers());
    frameCtr++;
    DrawPpuFrameWithPerf();

    // if vsync isn't working, delay manually
    curTick = SDL_GetTicks();
    static const uint8 delays[3] = { 17, 17, 16 }; // 60 fps
    lastTick += delays[frameCtr % 3];

    if (lastTick > curTick) {
      uint32 delta = lastTick - curTick;
      if (delta > 500) {
        lastTick = curTick - 500;
        delta = 500;
      }
      SDL_Delay(delta);
    } else if (curTick - lastTick > 500) {
      lastTick = curTick;
    }
  }
  if (g_config.autosave) HandleCommand(kKeys_Save + 0, true);
  return 0;
}

static void RenderDigit(uint8 *dst, size_t pitch, int digit, uint32 color, bool big) {
  static const uint8 kFont[] = { 0x1c, 0x36, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x36, 0x1c, 0x18, 0x1c, 0x1e, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x7e, 0x3e, 0x63, 0x60, 0x30, 0x18, 0x0c, 0x06, 0x03, 0x63, 0x7f, 0x3e, 0x63, 0x60, 0x60, 0x3c, 0x60, 0x60, 0x60, 0x63, 0x3e, 0x30, 0x38, 0x3c, 0x36, 0x33, 0x7f, 0x30, 0x30, 0x30, 0x78, 0x7f, 0x03, 0x03, 0x03, 0x3f, 0x60, 0x60, 0x60, 0x63, 0x3e, 0x1c, 0x06, 0x03, 0x03, 0x3f, 0x63, 0x63, 0x63, 0x63, 0x3e, 0x7f, 0x63, 0x60, 0x60, 0x30, 0x18, 0x0c, 0x0c, 0x0c, 0x0c, 0x3e, 0x63, 0x63, 0x63, 0x3e, 0x63, 0x63, 0x63, 0x63, 0x3e, 0x3e, 0x63, 0x63, 0x63, 0x7e, 0x60, 0x60, 0x60, 0x30, 0x1e };
  const uint8 *p = kFont + digit * 10;
  if (!big) { for (int y = 0; y < 10; y++, dst += pitch) { int v = *p++; for (int x = 0; v; x++, v >>= 1) if (v & 1) ((uint32 *)dst)[x] = color; } } 
  else { for (int y = 0; y < 10; y++, dst += pitch * 2) { int v = *p++; for (int x = 0; v; x++, v >>= 1) if (v & 1) { ((uint32 *)dst)[x * 2 + 1] = ((uint32 *)dst)[x * 2] = color; ((uint32 *)(dst + pitch))[x * 2 + 1] = ((uint32 *)(dst + pitch))[x * 2] = color; } } }
}

static void RenderNumber(uint8 *dst, size_t pitch, int n, uint8 big) {
  char buf[32], *s; int i; sprintf(buf, "%d", n);
  for (s = buf, i = 2 * 4; *s; s++, i += 8 * 4) RenderDigit(dst + ((pitch + i + 4) << big), pitch, *s - '0', 0x404040, big);
  for (s = buf, i = 2 * 4; *s; s++, i += 8 * 4) RenderDigit(dst + (i << big), pitch, *s - '0', 0xffffff, big);
}

#ifdef _WIN32
static void CustomSaveSnapshot() {
  SDL_SysWMinfo wmInfo; SDL_VERSION(&wmInfo.version);
  SDL_GetWindowWMInfo(g_window, &wmInfo);
  OPENFILENAME ofn; char szFile[260] = "mario_state.sav";
  memset(&ofn, 0, sizeof(ofn)); ofn.lStructSize = sizeof(ofn);
  ofn.hwndOwner = wmInfo.info.win.window; ofn.lpstrFile = szFile; ofn.nMaxFile = sizeof(szFile);
  ofn.lpstrFilter = "Save States\0*.sav\0All Files\0*.*\0";
  ofn.nFilterIndex = 1; ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;
  if (GetSaveFileName(&ofn) == TRUE) RtlSaveSnapshot(ofn.lpstrFile, false);
}

static void CustomLoadSnapshot() {
  SDL_SysWMinfo wmInfo; SDL_VERSION(&wmInfo.version);
  SDL_GetWindowWMInfo(g_window, &wmInfo);
  OPENFILENAME ofn; char szFile[260] = "";
  memset(&ofn, 0, sizeof(ofn)); ofn.lStructSize = sizeof(ofn);
  ofn.hwndOwner = wmInfo.info.win.window; ofn.lpstrFile = szFile; ofn.nMaxFile = sizeof(szFile);
  ofn.lpstrFilter = "Save States\0*.sav\0All Files\0*.*\0";
  ofn.nFilterIndex = 1; ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
  if (GetOpenFileName(&ofn) == TRUE) {
    FILE *f = fopen(ofn.lpstrFile, "rb");
    if (f) {
      RtlLoadFromFile(f, false);
      fclose(f);
    }
  }
}
#endif

static void HandleCommand(uint32 j, bool pressed) {
  static const uint8 kKbdRemap[] = { 4, 5, 6, 7, 2, 3, 8, 0, 9, 1, 10, 11 };
  if (j < kKeys_Controls) return;

  if (g_menu_open && pressed) {
    if (j == kKeys_Controls + 0) { // UP
      g_menu_cursor = (g_menu_cursor + 1) % 2;
      return;
    }
    if (j == kKeys_Controls + 1) { // DOWN
      g_menu_cursor = (g_menu_cursor + 1) % 2;
      return;
    }
    if (j == kKeys_Controls + 5) { // ENTER/START
      if (g_menu_cursor == 0) {
#ifdef _WIN32
        CustomSaveSnapshot();
#endif
      } else if (g_menu_cursor == 1) {
#ifdef _WIN32
        CustomLoadSnapshot();
#endif
      }
      return;
    }
    if (j == kKeys_CustomLoad) {
      g_menu_open = false;
      return;
    }
  }

  if (j <= kKeys_Controls_Last) { uint32 m = 1 << kKbdRemap[j - kKeys_Controls]; g_input_state = pressed ? (g_input_state | m) : (g_input_state & ~m); return; }
  if (!pressed) return;
  if (j <= kKeys_Load_Last) { RtlSaveLoad(kSaveLoad_Load, j - kKeys_Load); return; }
  if (j <= kKeys_Save_Last) { RtlSaveLoad(kSaveLoad_Save, j - kKeys_Save); return; }
  if (j == kKeys_ToggleAi) { g_ai_active = !g_ai_active; g_ai_capture_inputs = !g_ai_active; g_display_perf = g_ai_active; return; }
  if (j == kKeys_DisplayPerf) { g_display_perf ^= 1; return; }
  if (j == kKeys_WindowBigger) { ChangeWindowScale(1); return; }
  if (j == kKeys_WindowSmaller) { ChangeWindowScale(-1); return; }
  if (j == kKeys_CustomLoad) {
    if (misc_game_mode == 0x0E) {
      g_menu_open = !g_menu_open;
    }
    return;
  }
}

static void HandleInput(int keyCode, int keyMod, bool pressed) {
  int j = FindCmdForSdlKey(keyCode, (SDL_Keymod)keyMod);
  if (j != 0) HandleCommand(j, pressed);
}

static uint32 GetActiveControllers() { return (g_config.has_keyboard_controls | (g_gamepad[0].joystick_id != -1 ? 1 : 0)) << 30; }

static void OpenOneGamepad(int i) {
  if (SDL_IsGameController(i)) {
    SDL_GameController *controller = SDL_GameControllerOpen(i);
    uint32 joystick_id = SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(controller));
    if (GetGamepadInfo(joystick_id)) return;
    int found_idx = (g_gamepad[0].joystick_id == -1) ? 0 : (g_gamepad[1].joystick_id == -1) ? 1 : -1;
    if (found_idx >= 0) { g_gamepad[found_idx].joystick_id = joystick_id; g_gamepad[found_idx].index = found_idx; }
  }
}

static int RemapSdlButton(int button) {
  switch (button) {
  case SDL_CONTROLLER_BUTTON_A: return kGamepadBtn_A;
  case SDL_CONTROLLER_BUTTON_B: return kGamepadBtn_B;
  case SDL_CONTROLLER_BUTTON_X: return kGamepadBtn_X;
  case SDL_CONTROLLER_BUTTON_Y: return kGamepadBtn_Y;
  case SDL_CONTROLLER_BUTTON_BACK: return kGamepadBtn_Back;
  case SDL_CONTROLLER_BUTTON_GUIDE: return kGamepadBtn_Guide;
  case SDL_CONTROLLER_BUTTON_START: return kGamepadBtn_Start;
  case SDL_CONTROLLER_BUTTON_LEFTSTICK: return kGamepadBtn_L3;
  case SDL_CONTROLLER_BUTTON_RIGHTSTICK: return kGamepadBtn_R3;
  case SDL_CONTROLLER_BUTTON_LEFTSHOULDER: return kGamepadBtn_L1;
  case SDL_CONTROLLER_BUTTON_RIGHTSHOULDER: return kGamepadBtn_R1;
  case SDL_CONTROLLER_BUTTON_DPAD_UP: return kGamepadBtn_DpadUp;
  case SDL_CONTROLLER_BUTTON_DPAD_DOWN: return kGamepadBtn_DpadDown;
  case SDL_CONTROLLER_BUTTON_DPAD_LEFT: return kGamepadBtn_DpadLeft;
  case SDL_CONTROLLER_BUTTON_DPAD_RIGHT: return kGamepadBtn_DpadRight;
  default: return -1;
  }
}

static void HandleGamepadInput(GamepadInfo *gi, int button, bool pressed) {
  if (!!(gi->modifiers & (1 << button)) == pressed)
    return;
  gi->modifiers ^= 1 << button;
  if (pressed)
    gi->last_cmd[button] = FindCmdForGamepadButton(button + gi->index * kGamepadBtn_Count, gi->modifiers);
  if (gi->last_cmd[button] != 0)
    HandleCommand(gi->last_cmd[button], pressed);
}

static float ApproximateAtan2(float y, float x) {
  uint32 sign_mask = 0x80000000;
  float b = 0.596227f;
  uint32 ux_s = sign_mask & *(uint32 *)&x;
  uint32 uy_s = sign_mask & *(uint32 *)&y;
  float q = (float)((~ux_s & uy_s) >> 29 | ux_s >> 30);
  float bxy_a = b * x * y;
  if (bxy_a < 0.0f) bxy_a = -bxy_a;
  float num = bxy_a + y * y;
  float atan_1q = num / (x * x + bxy_a + num + 0.000001f);
  uint32_t uatan_2q = (ux_s ^ uy_s) | *(uint32 *)&atan_1q;
  return q + *(float *)&uatan_2q;
}

static void HandleGamepadAxisInput(GamepadInfo *gi, int axis, Sint16 value) {
  if (axis == SDL_CONTROLLER_AXIS_LEFTX || axis == SDL_CONTROLLER_AXIS_LEFTY) {
    *(axis == SDL_CONTROLLER_AXIS_LEFTX ? &gi->last_axis_x : &gi->last_axis_y) = value;
    int buttons = 0;
    if (gi->last_axis_x * gi->last_axis_x + gi->last_axis_y * gi->last_axis_y >= 10000 * 10000) {
      static const uint8 kSegmentToButtons[8] = {
        1 << 4,           // 0 = up
        1 << 4 | 1 << 7,  // 1 = up, right
        1 << 7,           // 2 = right
        1 << 7 | 1 << 5,  // 3 = right, down
        1 << 5,           // 4 = down
        1 << 5 | 1 << 6,  // 5 = down, left
        1 << 6,           // 6 = left
        1 << 6 | 1 << 4,  // 7 = left, up
      };
      uint8 angle = (uint8)(int)(ApproximateAtan2(gi->last_axis_y, gi->last_axis_x) * 64.0f + 0.5f);
      buttons = kSegmentToButtons[(uint8)(angle + 16 + 64) >> 5];
    }
    gi->axis_buttons = buttons;
  } else if ((axis == SDL_CONTROLLER_AXIS_TRIGGERLEFT || axis == SDL_CONTROLLER_AXIS_TRIGGERRIGHT)) {
    if (value < 12000 || value >= 16000)
      HandleGamepadInput(gi, axis == SDL_CONTROLLER_AXIS_TRIGGERLEFT ? kGamepadBtn_L2 : kGamepadBtn_R2, value >= 12000);
  }
}

static void HandleVolumeAdjustment(int volume_adjustment) {}

const uint8 *g_asset_ptrs[kNumberOfAssets];
uint32 g_asset_sizes[kNumberOfAssets];

static void LoadAssets() {
  size_t length = 0; uint8 *data = ReadWholeFile("smw_assets.dat", &length);
  if (!data) {
    size_t bps_length, bps_src_length; uint8 *bps = ReadWholeFile("smw_assets.bps", &bps_length), *bps_src = ReadWholeFile("smw.sfc", &bps_src_length);
    if (!bps || !bps_src) return;
    data = ApplyBps(bps_src, bps_src_length, bps, bps_length, &length);
  }
  if (!data) return;
  uint32 offset = 88 + kNumberOfAssets * 4 + *(uint32 *)(data + 84);
  for (size_t i = 0; i < kNumberOfAssets; i++) {
    uint32 size = *(uint32 *)(data + 88 + i * 4); offset = (offset + 3) & ~3;
    g_asset_sizes[i] = size; g_asset_ptrs[i] = data + offset; offset += size;
  }
}

MemBlk FindInAssetArray(int asset, int idx) { return FindIndexInMemblk((MemBlk) { g_asset_ptrs[asset], g_asset_sizes[asset] }, idx); }
const uint8 *FindPtrInAsset(int asset, uint32 addr) { return FindAddrInMemblk((MemBlk){g_asset_ptrs[asset], g_asset_sizes[asset]}, addr); }

static void SwitchDirectory(void) {
  char buf[4096]; if (!getcwd(buf, sizeof(buf) - 32)) return;
  size_t pos = strlen(buf);
  for (int step = 0; pos != 0 && step < 3; step++) {
    memcpy(buf + pos, "/smw.ini", 9); FILE *f = fopen(buf, "rb");
    if (f) { fclose(f); buf[pos] = 0; chdir(buf); return; }
    pos--; while (pos != 0 && buf[pos] != '/' && buf[pos] != '\\') pos--;
  }
}

void RtlLoadAssets(const uint8 *data) { LoadAssets(); }
